<!---
Copyright 2017 The AMP Start Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS-IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-->
<?php
$slug = $id;
$idBook = str_replace('.php', '', $page);
$idBookSlug = str_replace('.php', '', $page) . '-' . $slug;
$blacklist = file_get_contents('.blacklist');
$arrBlacklist = explode(',', $blacklist);
if (in_array($idBook, $arrBlacklist)) {
    header('location:' . SITE_HOST);
}
$titleBook = ucwords(str_replace('-', ' ', slugify($slug)));
?>
<!doctype html>
<html ⚡="" lang="en">

<head>
    <meta charset="utf-8">
    <title>Download <?= $titleBook ?> books in PDF format</title>
    <meta content="<?= $titleBook ?>,free book, textbook, study book, student, calculus, career, e-books, ebooks, economics"
          name="keywords"/>
    <meta content="Download <?= $titleBook ?> textbooks and business books in PDF format. The books are financed by a few in-book ads."
          name="description"/>

    <link rel="canonical" href="https://www.ampstart.com/templates/themes/e-commerce/product-details.amp">
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">

    <script async="" src="https://cdn.ampproject.org/v0.js"></script>
    <script async custom-element="amp-list" src="https://cdn.ampproject.org/v0/amp-list-0.1.js"></script>


    <style amp-boilerplate>body {
            -webkit-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
            -moz-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
            -ms-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
            animation: -amp-start 8s steps(1, end) 0s 1 normal both
        }

        @-webkit-keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }

        @-moz-keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }

        @-ms-keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }

        @-o-keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }

        @keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }</style>
    <noscript>
        <style amp-boilerplate>body {
                -webkit-animation: none;
                -moz-animation: none;
                -ms-animation: none;
                animation: none
            }</style>
    </noscript>


    <script custom-element="amp-sidebar" src="https://cdn.ampproject.org/v0/amp-sidebar-0.1.js" async=""></script>
    <script custom-element="amp-bind" src="https://cdn.ampproject.org/v0/amp-bind-0.1.js" async=""></script>
    <script custom-element="amp-carousel" src="https://cdn.ampproject.org/v0/amp-carousel-0.1.js" async=""></script>
    <script custom-element="amp-selector" src="https://cdn.ampproject.org/v0/amp-selector-0.1.js" async=""></script>

    <script custom-template="amp-mustache" src="https://cdn.ampproject.org/v0/amp-mustache-0.1.js" async=""></script>

    <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,700" rel="stylesheet">

    <style amp-custom>
        html {
            font-family: sans-serif;
            line-height: 1.15;
            -ms-text-size-adjust: 100%;
            -webkit-text-size-adjust: 100%
        }

        body {
            margin: 0
        }

        article, aside, footer, header, nav, section {
            display: block
        }

        h1 {
            font-size: 2em;
            margin: .67em 0
        }

        figcaption, figure, main {
            display: block
        }

        figure {
            margin: 1em 40px
        }

        hr {
            box-sizing: content-box;
            height: 0;
            overflow: visible
        }

        pre {
            font-family: monospace, monospace;
            font-size: 1em
        }

        a {
            background-color: transparent;
            -webkit-text-decoration-skip: objects
        }

        a:active, a:hover {
            outline-width: 0
        }

        abbr[title] {
            border-bottom: none;
            text-decoration: underline;
            text-decoration: underline dotted
        }

        b, strong {
            font-weight: inherit;
            font-weight: bolder
        }

        code, kbd, samp {
            font-family: monospace, monospace;
            font-size: 1em
        }

        dfn {
            font-style: italic
        }

        mark {
            background-color: #ff0;
            color: #000
        }

        small {
            font-size: 80%
        }

        sub, sup {
            font-size: 75%;
            line-height: 0;
            position: relative;
            vertical-align: baseline
        }

        sub {
            bottom: -.25em
        }

        sup {
            top: -.5em
        }

        audio, video {
            display: inline-block
        }

        audio:not([controls]) {
            display: none;
            height: 0
        }

        img {
            border-style: none
        }

        svg:not(:root) {
            overflow: hidden
        }

        button, input, optgroup, select, textarea {
            font-family: sans-serif;
            font-size: 100%;
            line-height: 1.15;
            margin: 0
        }

        button, input {
            overflow: visible
        }

        button, select {
            text-transform: none
        }

        [type=reset], [type=submit], button, html [type=button] {
            -webkit-appearance: button
        }

        [type=button]::-moz-focus-inner, [type=reset]::-moz-focus-inner, [type=submit]::-moz-focus-inner, button::-moz-focus-inner {
            border-style: none;
            padding: 0
        }

        [type=button]:-moz-focusring, [type=reset]:-moz-focusring, [type=submit]:-moz-focusring, button:-moz-focusring {
            outline: 1px dotted ButtonText
        }

        fieldset {
            border: 1px solid silver;
            margin: 0 2px;
            padding: .35em .625em .75em
        }

        legend {
            box-sizing: border-box;
            color: inherit;
            display: table;
            max-width: 100%;
            padding: 0;
            white-space: normal
        }

        progress {
            display: inline-block;
            vertical-align: baseline
        }

        textarea {
            overflow: auto
        }

        [type=checkbox], [type=radio] {
            box-sizing: border-box;
            padding: 0
        }

        [type=number]::-webkit-inner-spin-button, [type=number]::-webkit-outer-spin-button {
            height: auto
        }

        [type=search] {
            -webkit-appearance: textfield;
            outline-offset: -2px
        }

        [type=search]::-webkit-search-cancel-button, [type=search]::-webkit-search-decoration {
            -webkit-appearance: none
        }

        ::-webkit-file-upload-button {
            -webkit-appearance: button;
            font: inherit
        }

        details, menu {
            display: block
        }

        summary {
            display: list-item
        }

        canvas {
            display: inline-block
        }

        [hidden], template {
            display: none
        }

        .h3 {
            font-size: 1.75rem
        }

        .h5 {
            font-size: 1.125rem
        }

        .h6 {
            font-size: 1rem
        }

        .text-decoration-none {
            text-decoration: none
        }

        .caps {
            text-transform: uppercase;
            letter-spacing: 0
        }

        .center {
            text-align: center
        }

        .nowrap {
            white-space: nowrap
        }

        .list-reset {
            list-style: none;
            padding-left: 0
        }

        .block {
            display: block
        }

        .inline-block {
            display: inline-block
        }

        .m0 {
            margin: 0
        }

        .mx0 {
            margin-right: 0
        }

        .my0 {
            margin-top: 0;
            margin-bottom: 0
        }

        .mt1 {
            margin-top: .5rem
        }

        .mb1 {
            margin-bottom: .5rem
        }

        .ml1, .mx1 {
            margin-left: .5rem
        }

        .mx1 {
            margin-right: .5rem
        }

        .mt2 {
            margin-top: 1rem
        }

        .mr2 {
            margin-right: 1rem
        }

        .mb2 {
            margin-bottom: 1rem
        }

        .mb3 {
            margin-bottom: 1.5rem
        }

        .mb4 {
            margin-bottom: 2rem
        }

        .mxn1 {
            margin-left: -.5rem;
            margin-right: -.5rem
        }

        .mx-auto {
            margin-left: auto
        }

        .p0 {
            padding: 0
        }

        .pr0 {
            padding-right: 0
        }

        .px1 {
            padding-left: .5rem;
            padding-right: .5rem
        }

        .p2 {
            padding: 1rem
        }

        .pt2 {
            padding-top: 1rem
        }

        .pr2 {
            padding-right: 1rem
        }

        .pb2 {
            padding-bottom: 1rem
        }

        .pl2 {
            padding-left: 1rem
        }

        .px2 {
            padding-left: 1rem;
            padding-right: 1rem
        }

        .pt3 {
            padding-top: 1.5rem
        }

        .pr3 {
            padding-right: 1.5rem
        }

        .pb3 {
            padding-bottom: 1.5rem
        }

        .px3 {
            padding-left: 1.5rem;
            padding-right: 1.5rem
        }

        .pr4 {
            padding-right: 2rem
        }

        .pb4 {
            padding-bottom: 2rem
        }

        .col {
            float: left
        }

        .col, .col-right {
            box-sizing: border-box
        }

        .col-3 {
            width: 25%
        }

        .col-6 {
            width: 50%
        }

        .col-12 {
            width: 100%
        }

        @media (min-width: 40.06rem) {

            .sm-col-2 {
                width: 16.66667%
            }

            .sm-col-7 {
                width: 58.33333%
            }

        }

        @media (min-width: 52.06rem) {

            .md-col-2 {
                width: 16.66667%
            }

            .md-col-6 {
                width: 50%
            }

            .md-col-7 {
                width: 58.33333%
            }

            .md-col-8 {
                width: 66.66667%
            }

        }

        @media (min-width: 64.06rem) {

            .lg-col-2 {
                width: 16.66667%
            }

            .lg-col-7 {
                width: 58.33333%
            }
        }

        .flex {
            display: -webkit-box;
            display: -ms-flexbox;
            display: flex
        }

        @media (min-width: 40.06rem) {

        }

        @media (min-width: 52.06rem) {
            .md-flex {
                display: -webkit-box;
                display: -ms-flexbox;
                display: flex
            }
        }

        @media (min-width: 64.06rem) {

        }

        .flex-column {
            -webkit-box-orient: vertical;
            -webkit-box-direction: normal;
            -ms-flex-direction: column;
            flex-direction: column
        }

        .flex-wrap {
            -ms-flex-wrap: wrap;
            flex-wrap: wrap
        }

        .items-start {
            -webkit-box-align: start;
            -ms-flex-align: start;
            align-items: flex-start
        }

        .items-center {
            -webkit-box-align: center;
            -ms-flex-align: center;
            align-items: center
        }

        .self-start {
            -ms-flex-item-align: start;
            align-self: flex-start
        }

        .justify-start {
            -webkit-box-pack: start;
            -ms-flex-pack: start;
            justify-content: flex-start
        }

        .justify-center {
            -webkit-box-pack: center;
            -ms-flex-pack: center;
            justify-content: center
        }

        .justify-around {
            -ms-flex-pack: distribute;
            justify-content: space-around
        }

        .content-start {
            -ms-flex-line-pack: start;
            align-content: flex-start
        }

        .absolute {
            position: absolute
        }

        .fixed {
            position: fixed
        }

        .top-0 {
            top: 0
        }

        .right-0 {
            right: 0
        }

        .left-0 {
            left: 0
        }

        @media (max-width: 40rem) {

        }

        @media (min-width: 40.06rem) and (max-width: 52rem) {

        }

        @media (min-width: 52.06rem) and (max-width: 64rem) {
            .md-hide {
                display: none
            }
        }

        @media (min-width: 64.06rem) {
            .lg-hide {
                display: none
            }
        }

        .display-none {
            display: none
        }

        * {
            box-sizing: border-box
        }

        body {
            background: #fff;
            color: #222;
            font-family: Cardo, serif;
            min-width: 315px;
            overflow-x: hidden;
            font-smooth: always;
            -webkit-font-smoothing: antialiased
        }

        main {
            max-width: 1280px;
            margin: 0 auto
        }

        p {
            padding: 0;
            margin: 0
        }

        #content:target {
            margin-top: calc(0px - 3.5rem);
            padding-top: 3.5rem
        }

        .ampstart-label {
            text-transform: uppercase
        }

        .h3, h3 {
            font-size: 1.75rem;
            line-height: 2rem
        }

        .h5, h5 {
            font-size: 1.125rem;
            line-height: 1.125rem
        }

        .h6, h6 {
            font-size: 1rem;
            line-height: 1rem
        }

        h1, h2, h3, h4, h5, h6 {
            margin: 0;
            padding: 0;
            font-weight: 400;
            letter-spacing: .06rem
        }

        a, a:active, a:visited {
            color: inherit
        }

        .ampstart-btn {
            font-family: inherit;
            font-weight: inherit;
            font-size: 1rem;
            line-height: 1.125rem;
            padding: .7em .8em;
            text-decoration: none;
            white-space: nowrap;
            word-wrap: normal;
            vertical-align: middle;
            cursor: pointer;
            background-color: #222;
            color: #fff;
            border: 1px solid #fff
        }

        .ampstart-btn:visited {
            color: #fff
        }

        .ampstart-btn-secondary {
            background-color: #3cfe4b;
            color: #f88;
            border: 1px solid #f88
        }

        .ampstart-btn-secondary:visited {
            color: #f88
        }

        .ampstart-btn:active .ampstart-btn:focus {
            opacity: .8
        }

        .ampstart-btn[disabled], .ampstart-btn[disabled]:active, .ampstart-btn[disabled]:focus, .ampstart-btn[disabled]:hover {
            opacity: .5;
            outline: 0;
            cursor: default
        }

        @media (min-width: 40.06rem) {

        }

        @media (min-width: 52.06rem) {

            .md-h4 {
                font-size: 1.38rem
            }

        }

        @media (min-width: 64.06rem) {

        }

        @media (min-width: 40.06rem) {

        }

        @media (min-width: 52.06rem) {

            .md-mx2 {
                margin-right: 1rem
            }

            .md-mxn1 {
                margin-left: -.5rem;
                margin-right: -.5rem
            }

        }

        @media (min-width: 64.06rem) {

        }

        @media (min-width: 40.06rem) {

        }

        @media (min-width: 52.06rem) {

            .md-pt0 {
                padding-top: 0
            }

            .md-py3 {
                padding-top: 1.5rem;
                padding-bottom: 1.5rem
            }

            .md-pt4 {
                padding-top: 2rem
            }

            .md-pb4 {
                padding-bottom: 2rem
            }

            .md-px4 {
                padding-right: 2rem
            }

        }

        @media (min-width: 64.06rem) {

        }

        .ampstart-headerbar {
            background-color: #fff;
            color: #000;
            z-index: 999;
            box-shadow: 0 0 5px 2px rgba(0, 0, 0, .1)
        }

        .ampstart-headerbar + :not(amp-sidebar), .ampstart-headerbar + amp-sidebar + * {
            margin-top: 3.5rem
        }

        .ampstart-headerbar-nav .ampstart-nav-item {
            padding: 0 1rem;
            background: transparent;
            opacity: .8
        }

        .ampstart-nav-item:active, .ampstart-nav-item:focus, .ampstart-nav-item:hover {
            opacity: 1
        }

        .ampstart-navbar-trigger:focus {
            outline: none
        }

        .ampstart-nav a, .ampstart-navbar-trigger, .ampstart-sidebar-faq a {
            cursor: pointer;
            text-decoration: none
        }

        .ampstart-nav .ampstart-label {
            color: inherit
        }

        .ampstart-navbar-trigger {
            line-height: 3.5rem;
            font-size: 2.2rem
        }

        .ampstart-headerbar .ampstart-nav-search:active, .ampstart-headerbar .ampstart-nav-search:focus, .ampstart-headerbar .ampstart-nav-search:hover {
            box-shadow: none
        }

        .ampstart-nav-search > input {
            border: none;
            border-radius: 3px;
            line-height: normal
        }

        .ampstart-nav-dropdown amp-accordion header {
            background-color: #fff;
            border: none
        }

        .ampstart-nav-dropdown amp-accordion ul {
            background-color: #fff
        }

        .ampstart-nav-dropdown .ampstart-dropdown-item, .ampstart-nav-dropdown .ampstart-dropdown > section > header {
            background-color: #fff;
            color: #000
        }

        .ampstart-nav-dropdown .ampstart-dropdown-item {
            color: #f88
        }

        .ampstart-sidebar {
            background-color: #fff;
            color: #000;
            min-width: 300px;
            width: 300px
        }

        .ampstart-sidebar .ampstart-icon {
            fill: #f88
        }

        .ampstart-sidebar-header {
            line-height: 3.5rem;
            min-height: 3.5rem
        }

        .ampstart-sidebar .ampstart-dropdown-item, .ampstart-sidebar .ampstart-dropdown header, .ampstart-sidebar .ampstart-faq-item, .ampstart-sidebar .ampstart-nav-item, .ampstart-sidebar .ampstart-social-follow {
            margin: 0 0 2rem
        }

        .ampstart-sidebar .ampstart-nav-dropdown {
            margin: 0
        }

        .ampstart-sidebar .ampstart-navbar-trigger {
            line-height: inherit
        }

        .ampstart-navbar-trigger svg {
            pointer-events: none
        }

        .ampstart-input [disabled], .ampstart-input [disabled] + label {
            opacity: .5
        }

        .ampstart-input [disabled]:focus {
            outline: 0
        }

        .ampstart-input > input, .ampstart-input > select, .ampstart-input > textarea {
            width: 100%;
            margin-top: 1rem;
            line-height: 1.5rem;
            border: 0;
            border-radius: 0;
            border-bottom: 1px solid #4a4a4a;
            background: none;
            color: #4a4a4a;
            outline: 0
        }

        .ampstart-input > label {
            color: #222;
            pointer-events: none;
            text-align: left;
            font-size: 1.125rem;
            line-height: 1rem;
            opacity: 0;
            -webkit-animation: .2s;
            animation: .2s;
            -webkit-animation-timing-function: cubic-bezier(.4, 0, .2, 1);
            animation-timing-function: cubic-bezier(.4, 0, .2, 1);
            -webkit-animation-fill-mode: forwards;
            animation-fill-mode: forwards
        }

        .ampstart-input > input:focus, .ampstart-input > select:focus, .ampstart-input > textarea:focus {
            outline: 0
        }

        .ampstart-input > input:focus::-webkit-input-placeholder, .ampstart-input > select:focus::-webkit-input-placeholder, .ampstart-input > textarea:focus::-webkit-input-placeholder {
            color: transparent
        }

        .ampstart-input > input:focus::-moz-placeholder, .ampstart-input > select:focus::-moz-placeholder, .ampstart-input > textarea:focus::-moz-placeholder {
            color: transparent
        }

        .ampstart-input > input:focus:-ms-input-placeholder, .ampstart-input > select:focus:-ms-input-placeholder, .ampstart-input > textarea:focus:-ms-input-placeholder {
            color: transparent
        }

        .ampstart-input > input:focus::placeholder, .ampstart-input > select:focus::placeholder, .ampstart-input > textarea:focus::placeholder {
            color: transparent
        }

        .ampstart-input > input:not(:placeholder-shown):not([disabled]) + label, .ampstart-input > select:not(:placeholder-shown):not([disabled]) + label, .ampstart-input > textarea:not(:placeholder-shown):not([disabled]) + label {
            opacity: 1
        }

        .ampstart-input > input:focus + label, .ampstart-input > select:focus + label, .ampstart-input > textarea:focus + label {
            -webkit-animation-name: c;
            animation-name: c
        }

        .ampstart-input > label:after {
            content: "";
            height: 2px;
            position: absolute;
            bottom: 0;
            left: 45%;
            background: #222;
            -webkit-transition: .2s;
            transition: .2s;
            -webkit-transition-timing-function: cubic-bezier(.4, 0, .2, 1);
            transition-timing-function: cubic-bezier(.4, 0, .2, 1);
            visibility: hidden;
            width: 10px
        }

        .ampstart-input > input:focus + label:after, .ampstart-input > select:focus + label:after, .ampstart-input > textarea:focus + label:after {
            left: 0;
            width: 100%;
            visibility: visible
        }

        .ampstart-input > input[type=search] {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none
        }

        .ampstart-input > input[type=range] {
            border-bottom: 0
        }

        .ampstart-input > input[type=range] + label:after {
            display: none
        }

        .ampstart-input > select {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none
        }

        .ampstart-input > select + label:before {
            content: "⌄";
            line-height: 1.5rem;
            position: absolute;
            right: 5px;
            zoom: 2;
            top: 0;
            bottom: 0;
            color: #222
        }

        .ampstart-input input[type=checkbox], .ampstart-input input[type=radio] {
            margin-top: 0;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            width: 15px;
            height: 15px;
            border: 1px solid #222;
            vertical-align: middle;
            margin-right: .5rem;
            text-align: center
        }

        .ampstart-input input[type=radio] {
            border-radius: 15px
        }

        .ampstart-input input[type=checkbox]:not([disabled]) + label, .ampstart-input input[type=radio]:not([disabled]) + label {
            pointer-events: auto;
            -webkit-animation: none;
            animation: none;
            vertical-align: middle;
            opacity: 1;
            cursor: pointer
        }

        .ampstart-input input[type=checkbox] + label:after, .ampstart-input input[type=radio] + label:after {
            display: none
        }

        .ampstart-input input[type=checkbox]:after, .ampstart-input input[type=radio]:after {
            position: absolute;
            top: 0;
            left: 0;
            bottom: 0;
            right: 0;
            content: " ";
            line-height: 1.4rem;
            vertical-align: middle;
            text-align: center;
            background-color: #fff
        }

        .ampstart-input input[type=checkbox]:checked:after {
            background-color: #222;
            color: #fff;
            content: "✓"
        }

        .ampstart-input input[type=radio]:checked {
            background-color: #fff
        }

        .ampstart-input input[type=radio]:after {
            top: 3px;
            bottom: 3px;
            left: 3px;
            right: 3px;
            border-radius: 12px
        }

        .ampstart-input input[type=radio]:checked:after {
            content: "";
            font-size: 3.5rem;
            background-color: #222
        }

        .ampstart-input > label, _:-ms-lang(x) {
            opacity: 1
        }

        .ampstart-input > input:-ms-input-placeholder, _:-ms-lang(x) {
            color: transparent
        }

        .ampstart-input > input::placeholder, _:-ms-lang(x) {
            color: transparent
        }

        .ampstart-input > input::-ms-input-placeholder, _:-ms-lang(x) {
            color: transparent
        }

        .ampstart-input > select::-ms-expand {
            display: none
        }

        .ampstart-icon {
            fill: #f88
        }

        body {
            font-size: .94rem;
            line-height: normal
        }

        .h3 {
            color: #222
        }

        .h7 {
            font-size: .94rem
        }

        .h1, .h2, .h3, .h4, .h5, .h6, .h7, h1, h2, h3, h4, h5, h6, h7 {
            line-height: normal;
            letter-spacing: normal;
            font-family: Open Sans Condensed, sans-serif;
            text-transform: uppercase;
            font-weight: 700;
            color: #000
        }

        .mb5 {
            margin-bottom: 2.5rem
        }

        @media (min-width: 52.06rem) {

            .md-px4 {
                padding-left: 2rem;
                padding-right: 2rem
            }

            .md-pl5 {
                padding-left: 2.5rem
            }

            .md-pt6 {
                padding-top: 3rem
            }

            .md-pl7 {
                padding-left: 5rem
            }

            .md-pr7, .md-px7 {
                padding-right: 5rem
            }

            .md-pb7 {
                padding-bottom: 5rem
            }
        }

        hr {
            width: calc(100% + 2 * 1.5rem);
            height: 1px;
            background-color: #f3f3f3;
            border: none;
            margin: 0 -1.5rem
        }

        @media (min-width: 52.06rem) {
            hr {
                width: 100%;
                margin: 0
            }
        }

        dd:after {
            content: "";
            display: block
        }

        .commerce-loader, .commerce-loader:after, .commerce-loader:before {
            border-radius: 50%;
            width: .5rem;
            height: .5rem;
            -webkit-animation-fill-mode: both;
            animation-fill-mode: both;
            -webkit-animation: a 1.44s infinite ease-in-out;
            animation: a 1.44s infinite ease-in-out;
            will-change: contents
        }

        .commerce-loader {
            color: #666;
            margin: 24% auto;
            -webkit-animation-delay: .16s;
            animation-delay: .16s
        }

        .commerce-loader:after, .commerce-loader:before {
            content: "";
            position: absolute;
            top: 0
        }

        .commerce-loader:before {
            left: -1rem;
            -webkit-animation-delay: 0s;
            animation-delay: 0s
        }

        .commerce-loader:after {
            left: 1rem;
            -webkit-animation-delay: .32s;
            animation-delay: .32s
        }

        .commerce-hero-image .commerce-loader {
            margin-top: 200px
        }

        .commerce-listing-banner .commerce-loader {
            margin-top: 100px
        }

        @-webkit-keyframes a {
            0%, 80%, to {
                box-shadow: 0 1rem 0 -1rem
            }
            40% {
                box-shadow: 0 1rem 0 0
            }
        }

        @keyframes a {
            0%, 80%, to {
                box-shadow: 0 1rem 0 -1rem
            }
            40% {
                box-shadow: 0 1rem 0 0
            }
        }

        .commerce-select-wrapper {
            position: relative;
            padding-right: 13px
        }

        .commerce-select {
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
            border: none;
            border-radius: 0;
            background: none;
            color: #666
        }

        .amp-mode-mouse .commerce-select:hover {
            color: #222;
            cursor: pointer
        }

        .ampstart-input {
            width: 100%
        }

        .ampstart-input input::-webkit-input-placeholder, .ampstart-input input[type=email], .ampstart-input input[type=text], .ampstart-input label, textarea {
            font-size: .94rem;
            font-family: Open Sans Condensed, sans-serif;
            color: #222;
            font-weight: 700;
            text-transform: uppercase
        }

        .ampstart-input input::-moz-placeholder, .ampstart-input input[type=email], .ampstart-input input[type=text], .ampstart-input label, textarea {
            font-size: .94rem;
            font-family: Open Sans Condensed, sans-serif;
            color: #222;
            font-weight: 700;
            text-transform: uppercase
        }

        .ampstart-input input:-ms-input-placeholder, .ampstart-input input[type=email], .ampstart-input input[type=text], .ampstart-input label, textarea {
            font-size: .94rem;
            font-family: Open Sans Condensed, sans-serif;
            color: #222;
            font-weight: 700;
            text-transform: uppercase
        }

        .ampstart-input input::placeholder, .ampstart-input input[type=email], .ampstart-input input[type=text], .ampstart-input label, textarea {
            font-size: .94rem;
            font-family: Open Sans Condensed, sans-serif;
            color: #222;
            font-weight: 700;
            text-transform: uppercase
        }

        .ampstart-input input[type=email], .ampstart-input input[type=text] {
            margin-top: 1.5rem
        }

        .ampstart-input > label:after {
            height: 1px;
            background: #f3f3f3
        }

        .ampstart-input > input, .ampstart-input > textarea {
            border-bottom: 1px dashed #f3f3f3;
            color: #222
        }

        .ampstart-input-radio {
            display: block;
            margin-bottom: .5rem
        }

        .ampstart-input-radio label {
            font-family: Cardo, serif;
            font-weight: 400;
            text-transform: none;
            color: #222;
            font-size: .94rem
        }

        .amp-mode-mouse .ampstart-input-radio label:hover {
            text-decoration: underline
        }

        .ampstart-btn {
            border-color: #222;
            display: inline-block;
            font-size: .8rem;
            font-family: Open Sans Condensed, sans-serif;
            font-weight: 700;
            padding: .5rem 2rem;
            -webkit-transition: background-color .2s ease-in, color .2s ease-in;
            transition: background-color .2s ease-in, color .2s ease-in
        }

        .amp-mode-mouse .ampstart-btn:hover, .ampstart-btn-secondary {
            background-color: #fff;
            color: #222
        }

        .amp-mode-mouse .ampstart-btn-secondary:hover {
            background-color: #222;
            color: #fff
        }

        .ampstart-btn-secondary:visited {
            color: #222
        }

        amp-selector [option] {
            outline: 1px solid #f3f3f3
        }

        amp-selector [option]:hover {
            outline: 1px solid #222
        }

        amp-selector [option][selected] {
            outline-color: #222
        }

        .amp-carousel-button-next, .amp-carousel-button-prev {
            display: none
        }

        @media (min-width: 52.06rem) {
            .commerce-side-panel {
                position: -webkit-sticky;
                position: sticky;
                top: 5rem
            }

            .md-commerce-header {
                margin-top: 1.5rem;
                border-top: 1px solid #f3f3f3;
                border-bottom: 1px solid #f3f3f3
            }
        }

        .ampstart-pullquote {
            font-size: 2.2rem;
            margin: 1.5rem 0 1rem;
            line-height: 1.2;
            border-left: none;
            padding-left: 0
        }

        .commerce-pullquote-author {
            font-size: 1rem;
            margin-bottom: 1.5rem
        }

        .commerce-pullquote-author, .commerce-table {
            font-family: Open Sans Condensed, sans-serif;
            font-weight: 700
        }

        .commerce-table {
            border-collapse: collapse;
            width: 100%;
            min-width: 300px;
            max-width: 500px;
            text-transform: uppercase;
            color: #222
        }

        .commerce-table-header {
            background: #000;
            color: #fff
        }

        .commerce-table td, .commerce-table th {
            padding: 0;
            border: 1px solid #000;
            line-height: 3rem
        }

        .commerce-table td {
            border: 1px solid #e9e9e9;
            width: 25%;
            background-color: #fff
        }

        .commerce-table td:first-child {
            width: 50%
        }

        .main {
            margin-top: 3.5rem
        }

        @media (min-width: 52.06rem) {
            .main {
                min-height: calc(100vh - 181px - 5rem)
            }

            .ampstart-headerbar + :not(amp-sidebar), .ampstart-headerbar + amp-sidebar + *, .main {
                margin-top: 5rem
            }
        }

        .ampstart-headerbar {
            color: #f88;
            padding-right: 1rem;
            background-color: #fff;
            height: 3.5rem;
            box-shadow: none;
            border-bottom: 1px solid #f3f3f3
        }

        .ampstart-headerbar .ampstart-navbar-trigger {
            color: #222;
            font-size: 1.38rem;
            padding-right: 0
        }

        .ampstart-navbar-trigger:focus {
            outline: 5px auto -webkit-focus-ring-color
        }

        @media (min-width: 52.06rem) {
            .ampstart-headerbar {
                height: 5rem;
                border-bottom-color: #f3f3f3
            }

            .ampstart-headerbar .ampstart-navbar-trigger {
                margin-left: .5rem;
                top: .5rem
            }
        }

        .ampstart-headerbar-title {
            font-size: 1.38rem;
            font-weight: 700;
            line-height: normal;
            color: #222
        }

        @media (min-width: 52.06rem) {
            .ampstart-headerbar-title {
                font-size: 1.75rem
            }
        }

        .ampstart-headerbar-home-link {
            padding-bottom: 0
        }

        .ampstart-headerbar-icon-wrapper {
            width: 25px
        }

        @media (min-width: 52.06rem) {
            .ampstart-headerbar-fixed {
                top: .5rem
            }
        }

        .ampstart-headerbar-fixed-link {
            margin-right: 0
        }

        .ampstart-sidebar {
            background-color: #fff;
            width: 350px;
            margin-bottom: 1.5rem;
            text-align: center
        }

        @media (min-width: 52.06rem) {
            .ampstart-sidebar {
                width: 25%
            }

            .ampstart-sidebar-nav {
                display: inline-block;
                text-align: center
            }
        }

        .ampstart-sidebar-nav-image {
            width: 120px
        }

        .ampstart-icon, .ampstart-sidebar .ampstart-icon {
            fill: #222
        }

        .ampstart-sidebar-header {
            position: relative;
            z-index: 1
        }

        @media (min-width: 52.06rem) {
            .ampstart-sidebar-header {
                position: absolute;
                top: 1rem;
                left: 2rem
            }
        }

        .ampstart-sidebar .ampstart-navbar-trigger {
            margin-top: 1rem;
            font-size: 1.5rem;
            line-height: normal;
            top: 0
        }

        @media (min-width: 52.06rem) {
            .ampstart-sidebar .ampstart-navbar-trigger {
                margin-top: .5rem;
                padding-top: 0
            }
        }

        .ampstart-nav {
            margin-bottom: 2rem
        }

        .ampstart-nav-item {
            color: #222
        }

        .ampstart-sidebar .ampstart-nav-item {
            margin-bottom: 1rem
        }

        .ampstart-nav-link {
            font-family: Open Sans Condensed, sans-serif;
            font-size: 1.75rem;
            font-weight: 700;
            line-height: normal;
            display: inline-block;
            margin-bottom: 1rem;
            position: relative
        }

        .amp-mode-mouse .ampstart-nav-link:after {
            background-color: #222;
            left: 0;
            position: absolute;
            -webkit-transform: scaleX(0);
            transform: scaleX(0);
            -webkit-transform-origin: left center;
            transform-origin: left center;
            -webkit-transition: -webkit-transform .3s cubic-bezier(.19, 1, .22, 1);
            transition: -webkit-transform .3s cubic-bezier(.19, 1, .22, 1);
            transition: transform .3s cubic-bezier(.19, 1, .22, 1);
            transition: transform .3s cubic-bezier(.19, 1, .22, 1), -webkit-transform .3s cubic-bezier(.19, 1, .22, 1);
            width: 100%;
            bottom: 0;
            height: 2px;
            content: "";
            display: block
        }

        .amp-mode-mouse .ampstart-nav-link:hover:after {
            -webkit-transform: scaleX(1);
            transform: scaleX(1)
        }

        .ampstart-sidebar .ampstart-faq-item {
            margin: 0
        }

        .ampstart-sidebar-faq {
            width: 100%;
            color: #222;
            font-family: Cardo, serif;
            padding-top: 1rem
        }

        .ampstart-faq-item {
            line-height: normal;
            padding: 0 0 .5rem
        }

        .amp-mode-mouse .ampstart-faq-item:hover {
            text-decoration: underline
        }

        .ampstart-sidebar .ampstart-social-follow {
            margin: .5rem 0 1rem
        }

        .ampstart-social-follow {
            -webkit-box-pack: initial;
            -ms-flex-pack: initial;
            justify-content: initial;
            display: inline-block
        }

        .ampstart-social-follow li {
            display: inline-block;
            margin-right: 0
        }

        .commerce-landing, .commerce-listing {
            max-width: none
        }

        .commerce-hero-content {
            padding: 3rem 1.5rem
        }

        .amp-mode-mouse .commerce-hero-image {
            -webkit-transition: -webkit-transform 1s;
            transition: -webkit-transform 1s;
            transition: transform 1s;
            transition: transform 1s, -webkit-transform 1s
        }

        .amp-mode-mouse .commerce-hero-content-wrapper:hover .commerce-hero-image {
            -webkit-transform: scale(1.05);
            transform: scale(1.05)
        }

        .commerce-hero-content-body {
            padding: 1rem 1rem 1.5rem;
            font-family: Cardo, serif;
            width: 100%;
            max-width: 500px;
            margin: 0 auto
        }

        .commerce-hero-content-title {
            font-weight: 700
        }

        @media (min-width: 52.06rem) {
            .commerce-hero-content-wrapper {
                position: relative;
                color: #fff;
                text-align: left
            }

            .commerce-hero-content-title {
                font-size: 3.5rem;
                color: #fff;
                font-weight: 700;
                line-height: 1;
                max-width: 500px
            }

            .commerce-hero-content-body {
                font-size: 1rem;
                margin-bottom: 2rem;
                margin-left: 0;
                padding-left: 2rem
            }

            .commerce-hero-align {
                width: 100%;
                max-width: 1280px
            }

            .commerce-hero-content {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                padding: 0
            }

            .commerce-hero-content-wrapper .ampstart-btn {
                background-color: #fff;
                border: none;
                color: #222;
                font-size: .94rem
            }

            .commerce-hero-content-theme-secondary, .commerce-hero-content-theme-secondary .commerce-hero-content-title {
                color: #222
            }

            .commerce-hero-content-theme-secondary .ampstart-btn {
                color: #fff;
                background-color: #222
            }

            .amp-mode-mouse .commerce-hero-content-theme-secondary .ampstart-btn:hover {
                background-color: #fff;
                color: #222
            }
        }

        .icon-star, .icon-star-empty {
            height: 14px;
            width: 14px;
            color: #f9ab00
        }

        .icon-star-empty {
            color: #dadada
        }

        .commerce-product-btn-wrapper {
            text-align: center
        }

        @media (min-width: 52.06rem) {
            .commerce-product-btn-wrapper {
                text-align: initial
            }
        }

        .commerce-product-color-swatch {
            height: 24px;
            width: 24px;
            margin-left: .5rem
        }

        .commerce-product-color-swatch:first-child {
            margin-left: 0
        }

        .commerce-product-color-blue {
            background-color: #1d4cdf
        }

        .commerce-product-color-black {
            background-color: #000
        }

        .commerce-product-thumb {
            width: 43px;
            margin-left: .5rem
        }

        .commerce-product-thumb:first-child {
            margin-left: 0
        }

        @media (min-width: 52.06rem) {
            .commerce-product-thumb {
                width: 80px
            }

            .commerce-product-desc {
                margin-right: 8.33333%
            }
        }

        .commerce-cart-notification .commerce-cart-icon, .commerce-checkout .commerce-cart-icon {
            display: none
        }

        .commerce-cart-notification {
            background-color: #fff;
            border: 1px solid #f3f3f3;
            box-shadow: 0 6px 12px -3px #222;
            display: block;
            z-index: 1000;
            opacity: 0;
            pointer-events: none
        }

        .commerce-cart-added .commerce-cart-notification {
            -webkit-animation: b 2.5s 0s;
            animation: b 2.5s 0s;
            pointer-events: auto
        }

        @-webkit-keyframes b {
            0%, to {
                opacity: 0
            }
            10%, 90% {
                opacity: 1
            }
        }

        @keyframes b {
            0%, to {
                opacity: 0
            }
            10%, 90% {
                opacity: 1
            }
        }

        @media (min-width: 52.06rem) {
            .commerce-cart-notification {
                top: calc(5rem - 1rem);
                width: auto
            }

            .commerce-cart-notification:before {
                background: #fff;
                border-top: 1px solid #f3f3f3;
                border-left: 1px solid #f3f3f3;
                content: "";
                height: .5rem;
                width: .5rem;
                position: absolute;
                top: -1px;
                right: .5rem;
                -webkit-transform: translate(-50%, -50%) rotate(45deg);
                transform: translate(-50%, -50%) rotate(45deg)
            }
        }

        .commerce-blog-wrapper {
            background-color: #fff
        }

        .commerce-blog-wrapper p {
            line-height: 1.6
        }

        .commerce-blog-sidebar .ampstart-social-follow li:first-child a {
            margin-left: -.5rem
        }

        .commerce-listing-banner {
            width: 100%
        }

        .commerce-checkout-steps, .commerce-listing-filters {
            border-top: 1px solid #f3f3f3;
            border-bottom: 1px solid #f3f3f3
        }

        @media (min-width: 52.06rem) {
            .commerce-listing-filters {
                border: none
            }
        }

        .commerce-listing-content {
            max-width: 1280px
        }

        .commerce-listing-product, .commerce-listing-product > div {
            min-height: 275px
        }

        .commerce-listing-product-image {
            border-bottom: 1px dashed #dadada
        }

        .amp-mode-mouse .commerce-listing-product:hover > .commerce-listing-product-name {
            text-decoration: underline
        }

        .commerce-footer {
            background-color: #222
        }

        .commerce-footer h3 {
            padding-top: 0
        }

        .amp-mode-mouse .commerce-footer a:hover {
            text-decoration: underline
        }

        .commerce-footer, .commerce-footer-header, .commerce-footer h3 {
            color: #fff
        }

        .commerce-footer hr {
            background-color: #4a4a4a
        }

        .commerce-footer nav {
            max-width: 1280px
        }

        .commerce-footer .ampstart-icon {
            fill: #6a6a6a
        }

        .commerce-footer .ampstart-social-follow {
            margin-bottom: 0
        }

        @media (min-width: 52.06rem) {
            .commerce-footer {
                text-align: initial
            }

            .commerce-footer .ampstart-social-follow li:first-child a {
                padding-left: 0
            }
        }

        .commerce-checkout-steps {
            color: #cdcccd
        }

        @media (min-width: 52.06rem) {
            .commerce-checkout-actions {
                text-align: initial
            }

            .commerce-checkout-steps {
                max-width: 350px;
                border: none;
                -webkit-box-pack: justify;
                -ms-flex-pack: justify;
                justify-content: space-between
            }
        }

        .commerce-checkout .commerce-cart-icon {
            display: none
        }

        .commerce-checkout .commerce-cart-item {
            margin-left: 0
        }

        .commerce-cart-icon {
            color: #f88
        }

        .commerce-cart-total {
            border-top: 1px solid #f3f3f3;
            border-bottom: 1px solid #f3f3f3
        }

        @media (min-width: 52.06rem) {
            .commerce-cart-item-price {
                -webkit-box-pack: justify;
                -ms-flex-pack: justify;
                justify-content: space-between
            }
        }

        @media (max-width: 40rem) {
            .commerce-cart-item-desc {
                margin-top: 2rem
            }
        }

        .commerce-cart-added .ampstart-headerbar-icon-wrapper:after {
            content: "1";
            display: block;
            width: 17px;
            height: 17px;
            position: absolute;
            top: -10px;
            right: -10px;
            border-radius: 50%;
            background-color: #f88;
            color: #fff;
            font: 700 .7rem Open Sans Condensed, sans-serif;
            opacity: 0;
            -webkit-animation: c .5s forwards;
            animation: c .5s forwards
        }

        @-webkit-keyframes c {
            to {
                opacity: 1
            }
        }

        @keyframes c {
            to {
                opacity: 1
            }
        }

        .commerce-cart .commerce-related-products {
            border-top: none
        }

        @media (min-width: 52.06rem) {
            .commerce-cart-item {
                border-bottom: 1px solid #f3f3f3
            }

            .commerce-cart-actions {
                text-align: left
            }

            .commerce-cart-item-image {
                max-width: 100px
            }
        }

        .commerce-related-products {
            border-top: 1px solid #f3f3f3
        }

        .commerce-related-products .amp-carousel-button {
            background: url('data:image/svg+xml;charset=utf-8,<svg xmlns="http://www.w3.org/2000/svg" width="30" height="30" viewBox="0 0 24 24"><path d="M15.41 16.09l-4.58-4.59 4.58-4.59L14 5.5l-6 6 6 6z"/><path d="M0-.5h24v24H0z" fill="none"/></svg>') 30px 30px transparent;
            cursor: pointer;
            height: 30px;
            width: 30px;
            top: 40%
        }

        .commerce-related-products .amp-carousel-button-next, .commerce-related-products .amp-carousel-button-prev {
            display: initial
        }

        .commerce-related-products .amp-carousel-button-prev {
            left: 0
        }

        .commerce-related-products .amp-carousel-button-next {
            right: 0;
            -webkit-transform: translateY(-50%) rotate(180deg);
            transform: translateY(-50%) rotate(180deg)
        }

        .commerce-related-product {
            width: 105px;
            overflow: hidden;
            text-overflow: ellipsis
        }

        .bg {
            background-color: #dfd4fe;
        }

        .mb3 {
            font-family: Arial;
            text-align: justify;
            text-justify: inter-word;
        }

        td {
            padding: 5px
        }

        .amp-mode-mouse .commerce-related-product:hover .commerce-related-product-name {
            text-decoration: underline
        }
    </style>

    <?php
    $datajson = file_get_contents(SITE_HOST."/get.php?action=get_single_json&param=$idBookSlug");
    $arrData = json_decode($datajson);
    $dataBuku = $arrData->items[0];
//    print_r($arrData);exit;
    ?>
    <script type="application/ld+json">
    {
      "@context": "http://schema.org",
      "@type": "NewsArticle",
      "headline": "<?=trim($dataBuku->title)?>",
      "author": "<?=trim($dataBuku->author)?>",
      "publisher": "Ballantine Books",
      "image": [
        "<?=$dataBuku->img?>"
      ],
      "datePublished": "<?=date('Y')?>-<?=date('m')?>-<?=date('d')-1?>T08:00:00+08:00"
    }


    </script>
</head>

<body [class]="cart.added ? 'commerce-cart-added' : ''">

<!-- Start Navbar -->
<header class="ampstart-headerbar fixed flex justify-start items-center top-0 left-0 right-0 pl2 pr4 pt2 md-pt0">
    <div role="button" aria-label="open sidebar" on="tap:header-sidebar.toggle" tabindex="0"
         class="ampstart-navbar-trigger  pr2 absolute top-0 pr0 mr2 mt2">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" class="block">
            <path fill="none" d="M0 0h24v24H0z"></path>
            <path fill="currentColor" d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"></path>
        </svg>
    </div>
    <a href="<?= SITE_HOST ?>"
       class="text-decoration-none inline-block mx-auto ampstart-headerbar-home-link mb1 md-mb0 ">
        <amp-img src="../../img/e-commerce/logo.png" width="200" height="75" layout="fixed" class="my0 mx-auto "
                 alt=""></amp-img>
    </a>
    <!--
      TODO: currently "fixeditems" is an array, therefore it's not possible to
      add additional classes to it. An alternative solution would be to make it
      an oject, with a "classes" and "items" sub-properties:
     "fixeditems": {
       "classes": "col-3",
       "items": [{
         "link": {
           "url": "mailto:contact@lune.com",
           "text": "—contact@lune.com",
           "classes": "xs-small sm-hide h6 bold"
         }
       }]
     }
     -->
    <div class="ampstart-headerbar-fixed center m0 p0 flex justify-center nowrap absolute top-0 right-0 pt2 pr3">
        <div class="mr2">
        </div>

    </div>
</header>

<!-- Start Sidebar -->
<amp-sidebar id="header-sidebar"
             class="ampstart-sidebar px3  md-flex flex-column justify-content items-center justify-center"
             layout="nodisplay">
    <div class="flex justify-start items-center ampstart-sidebar-header">
        <div role="button" aria-label="close sidebar" on="tap:header-sidebar.toggle" tabindex="0"
             class="ampstart-navbar-trigger items-start">✕
        </div>
    </div>
    <nav class="ampstart-sidebar-nav ampstart-nav">
        <ul class="list-reset m0 p0 ampstart-label">
            <li>
                <a href="<?= SITE_HOST ?>" class="text-decoration-none block 22">
                    <amp-img src="<?= SITE_HOST ?>/img/e-commerce/logo-nav.png" width="279" height="175"
                             layout="responsive"
                             class="ampstart-sidebar-nav-image inline-block mb4" alt="Company logo" noloading="">
                        <div placeholder="" class="commerce-loader"></div>
                    </amp-img>
                </a>
            </li>
            <li class="ampstart-nav-item "><a class="ampstart-nav-link" href="<?= SITE_HOST ?>/privacy">Privacy
                    Policy</a>
            </li>
            <li class="ampstart-nav-item "><a class="ampstart-nav-link" href="<?= SITE_HOST ?>/dmca">DMCA</a></li>
            <li class="ampstart-nav-item "><a class="ampstart-nav-link" href="<?= SITE_HOST ?>/contact">Contact us</a>
            </li>
        </ul>
    </nav>
</amp-sidebar>
<!-- End Sidebar -->
<!-- End Navbar -->

<amp-state id="cart">
    <script type="application/json">
        {
            "added": false
        }
    </script>
</amp-state>

<main id="content" role="main" class="main">
    <div class="commerce-cart-notification fixed col-12 right-0 mx0 md-mx2">
        <h1 class="display-none   ">Your Basket</h1>
        <div class="commerce-cart-item flex flex-wrap items-center m0 p2 ">
            <div class="col-3 sm-col-2 md-col-2 lg-col-2">
                <!--<amp-img class="commerce-cart-item-image" src="../../img/e-commerce/product/product-8.jpg" width="1"
                         height="1" layout="responsive" alt="Caliper Brakes" noloading="">
                    <div placeholder="" class="commerce-loader"></div>
                </amp-img>-->
                <amp-img class="commerce-cart-item-image" src="../../img/e-commerce/product/product-8.jpg" width="1"
                         height="1" layout="responsive" alt="Caliper Brakes" noloading="">
                    <div placeholder="" class="commerce-loader"></div>
                </amp-img>
            </div>
            <div class="commerce-cart-item-desc px1 col-6 sm-col-7 md-col-7 lg-col-7">
                <div class="h6 mb1">Caliper Brakes</div>
                <div>Fits most wheel sizes and designed to last long.</div>
            </div>
            <div class="commerce-cart-item-price col-3 h6 flex flex-wrap justify-around items-start">
                <span>£349</span>
                <span>1</span>
                <div role="button" class="inline-block commerce-cart-icon" tabindex="0">✕</div>
            </div>
        </div>
        <div class="commerce-cart-item flex flex-wrap items-center m0 p2 ">
            <div class="col-3 sm-col-2 md-col-2 lg-col-2">
                <amp-img class="commerce-cart-item-image" src="../../img/e-commerce/product/product-1.jpg" width="1"
                         height="1" layout="responsive" alt="Sprocket Set" noloading="">
                    <div placeholder="" class="commerce-loader"></div>
                </amp-img>
            </div>
            <div class="commerce-cart-item-desc px1 col-6 sm-col-7 md-col-7 lg-col-7">
                <div class="h6 mb1">Sprocket Set</div>
                <div>Steel, designed for long lasting stability.</div>
            </div>
            <div class="commerce-cart-item-price col-3 h6 flex flex-wrap justify-around items-start">
                <span>£470</span>
                <span>1</span>
                <div role="button" class="inline-block commerce-cart-icon" tabindex="0">✕</div>
            </div>
        </div>
        <div class="flex p2 mxn1 md-py3">
            <a href="#" class="ampstart-btn ampstart-btn-secondary caps center col col-6 mx1">send</a>
            <a href="checkout.amp.html" class="ampstart-btn caps center col col-6 mx1">checkout</a>
        </div>
    </div>

    <amp-list class="mx1 md-mxn1" [src]="'api/' + products.filter + '-' + products.category + '-products.json'"
              src="//<?= DOMAIN ?>/get.php?action=get_single_json&param=<?= $idBookSlug ?>" height="1000px" width="300"
              layout="responsive">
        <template type="amp-mustache">
            <section class="flex flex-wrap pb4 md-pb7">
                <div class="col-12 md-col-6 px2 pt2 md-pl7 md-pt4">
                    <amp-carousel width="1280" height="720" layout="responsive" type="slides"
                                  [slide]="product.selectedSlide"
                                  on="slideChange: AMP.setState({product: {selectedSlide: event.index}})">
                        <amp-img [src]="{{img}}"
                                 src="{{img}}" width="1280" height="720" layout="responsive"
                                 role="button" tabindex="0" alt="{{title}}" noloading="">
                            <div placeholder="" class="commerce-loader"></div>
                        </amp-img>
                    </amp-carousel>
                </div>
                <div class="col-12 md-col-6 flex flex-wrap content-start px2 md-pl5 md-pr7 md-pt4">
                    <div class="col-12 self-start pb2">
                        <h1 class="h3 md-h2">{{title}}</h1>
                    </div>
                    <div class="col-md-12 row self-start pb4">
                        <table>
                            <tr class="bg">
                                <td><b>Author</b></td>
                                <td class=""> {{author}}</td>
                                <!--<td rowspan="5">
                                    <amp-img src="{{bookAuthorProfile__photo}}" alt="author" height="120"
                                             width="120">
                                    </amp-img>
                                    <amp-img src="<? /*=SITE_HOST*/ ?>/img/us1.png" alt="author" height="150" width="85"></amp-img>
                                </td>-->
                            </tr>
                            <tr>
                                <td class=""><b>ISBN</b></td>
                                <td class=""> {{isbn}}</td>
                            </tr>
                            <tr class="bg">
                                <td><b>Format</b></td>
                                <td class=""> {{format}}</td>
                            </tr>
                            <tr>
                                <td class=""><b>Published</b></td>
                                <td class=""> {{published}}</td>
                            </tr>
                            <tr class="bg">
                                <td><b>Language</b></td>
                                <td class=""> {{language}}</td>
                            </tr>
                        </table>
                    </div>
                    <div class="col-12 self-start mb4 commerce-product-btn-wrapper">
                        <a href="<?= LINK_CPA ?>">
                            <button class="ampstart-btn ampstart-btn-secondary caps btn-danger">
                                Download Now
                            </button>
                        </a>
                    </div>
                    <hr class="md-hide lg-hide">
                </div>
                <div class="col-12 flex flex-wrap pb3">
                    <div class="col-12 md-col-8 px2 md-pl7 commerce-product-desc">
                        <section class="pt3 md-pt6 md-px4">
                            <h2 class="h5 md-h4">Overview</h2>
                            <p class="mt2 mb3">{{desc}}</p>
                            <hr>

                            <div class="pt3 md-pt4 md-pb4">
                                <h2 class="h5 md-h4 mb2">Reviews</h2>
                                <section class="mb3">
                                    <table>
                                        <tr>
                                            <td>
                                                <amp-img src="<?= SITE_HOST ?>/img/5.jpg" alt="Welcome" height="60"
                                                         width="60"></amp-img>
                                            </td>
                                            <td>
                                                <h3 class="h7 mb1">Tom - UK</h3>
                                                <p class="mt1">Finally I get this ebook, thanks for all these Advanced
                                                    Analytics
                                                    with Spark: Patterns for Learning from Data at Scale I can get
                                                    now!</p>
                                            </td>
                                        </tr>
                                    </table>
                                </section>
                                <section class="mb3">
                                    <table>
                                        <tr>
                                            <td>
                                                <amp-img src="<?= SITE_HOST ?>/img/1.jpg" alt="Welcome" height="60"
                                                         width="60"></amp-img>
                                            </td>
                                            <td>
                                                <h3 class="h7 mb1">Jessica - UK</h3>
                                                <p class="mt1">I was suspicious at first when I got redirected to the
                                                    membership site. Now I'm really excited I found this online
                                                    library....many thanks Kisses</p>
                                            </td>
                                        </tr>
                                    </table>
                                </section>
                                <section class="mb3">
                                    <table>
                                        <tr>
                                            <td>
                                                <amp-img src="<?= SITE_HOST ?>/img/7.jpg" alt="Welcome" height="60"
                                                         width="60"></amp-img>
                                            </td>
                                            <td>
                                                <h3 class="h7 mb1">Arthur - UK</h3>
                                                <p class="mt1">I stumbled upon Playster 2 months ago. I've upgraded to a
                                                    premium
                                                    membership already. The platform now carries audiobooks from: Simon
                                                    & Schuster,
                                                    Macmillan, HarperCollins UK, Recorded Books, Tantor, and Highbridge.
                                                    HarperCollins US titles are already in the library. Great
                                                    service.</p>
                                            </td>
                                        </tr>
                                    </table>
                                </section>

                                <section class="mb4">
                                    <table>
                                        <tr>
                                            <td>
                                                <amp-img src="<?= SITE_HOST ?>/img/9.jpg" alt="" height="60"
                                                         width="60">
                                                </amp-img>
                                            </td>
                                            <td>
                                                <h3 class="h7 mb1">Lukasz Czaru - US</h3>
                                                <p class="mt1">so many fake sites. this is the first one which worked!
                                                    Many thanks</p>
                                            </td>
                                        </tr>
                                    </table>
                                </section>

                                <section class="mb5">
                                    <table>
                                        <tr>
                                            <td>
                                                <amp-img src="<?= SITE_HOST ?>/img/11.jpg" alt="" height="60"
                                                         width="60"></amp-img>
                                            </td>
                                            <td>
                                                <h3 class="h7 mb1">Martin Borton - US</h3>
                                                <p class="mt1">Just click on the download, read now or start a free
                                                    trial buttons and create an
                                                    account.
                                                    It only takes 5 minutes to start your one month trial, and after you
                                                    can
                                                    download not just this eBook but many others ;)</p>
                                            </td>
                                        </tr>
                                    </table>
                                </section>
                            </div>
                        </section>
                    </div>
                </div>
            </section>
        </template>
    </amp-list>


</main>
<?php
include_once 'footer.php';
?>
</body>
</html>
