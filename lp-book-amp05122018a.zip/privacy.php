<!---
Copyright 2017 The AMP Start Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS-IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-->
<?php
include_once '../config.php';
//$dataSingle = get_single_json($slug);
//print_r($dataSingle);exit;
?>
<!doctype html>
<html ⚡="" lang="en">

<head>
    <meta charset="utf-8">
    <title>Privacy Policy</title>
    <link rel="canonical" href="https://www.ampstart.com/templates/themes/e-commerce/product-details.amp">
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">

    <script async="" src="https://cdn.ampproject.org/v0.js"></script>
    <script async custom-element="amp-list" src="https://cdn.ampproject.org/v0/amp-list-0.1.js"></script>


    <style amp-boilerplate="">
        body {
            -webkit-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
            -moz-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
            -ms-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
            animation: -amp-start 8s steps(1, end) 0s 1 normal both
        }

        @-webkit-keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }

        @-moz-keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }

        @-ms-keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }

        @-o-keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }

        @keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }</style>
    <noscript>
        <style amp-boilerplate="">body {
                -webkit-animation: none;
                -moz-animation: none;
                -ms-animation: none;
                animation: none
            }</style>
    </noscript>


    <script custom-element="amp-sidebar" src="https://cdn.ampproject.org/v0/amp-sidebar-0.1.js" async=""></script>
    <script custom-element="amp-bind" src="https://cdn.ampproject.org/v0/amp-bind-0.1.js" async=""></script>
    <script custom-element="amp-carousel" src="https://cdn.ampproject.org/v0/amp-carousel-0.1.js" async=""></script>
    <script custom-element="amp-selector" src="https://cdn.ampproject.org/v0/amp-selector-0.1.js" async=""></script>

    <script custom-template="amp-mustache" src="https://cdn.ampproject.org/v0/amp-mustache-0.1.js" async=""></script>

    <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,700" rel="stylesheet">

    <link href="<?=SITE_HOST?>/css/custom.css" rel="stylesheet">
</head>

<body [class]="cart.added ? 'commerce-cart-added' : ''">

<!-- Start Navbar -->
<header class="ampstart-headerbar fixed flex justify-start items-center top-0 left-0 right-0 pl2 pr4 pt2 md-pt0">
    <div role="button" aria-label="open sidebar" on="tap:header-sidebar.toggle" tabindex="0"
         class="ampstart-navbar-trigger  pr2 absolute top-0 pr0 mr2 mt2">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" class="block">
            <path fill="none" d="M0 0h24v24H0z"></path>
            <path fill="currentColor" d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"></path>
        </svg>
    </div>
    <a href="<?=SITE_HOST?>"
       class="text-decoration-none inline-block mx-auto ampstart-headerbar-home-link mb1 md-mb0 ">
        <amp-img src="<?=SITE_HOST?>/img/e-commerce/logo.png" width="200" height="75" layout="fixed" class="my0 mx-auto "
                 alt="">

        </amp-img>
    </a>
    <!--
      TODO: currently "fixeditems" is an array, therefore it's not possible to
      add additional classes to it. An alternative solution would be to make it
      an oject, with a "classes" and "items" sub-properties:
     "fixeditems": {
       "classes": "col-3",
       "items": [{
         "link": {
           "url": "mailto:contact@lune.com",
           "text": "—contact@lune.com",
           "classes": "xs-small sm-hide h6 bold"
         }
       }]
     }
     -->
    <div class="ampstart-headerbar-fixed center m0 p0 flex justify-center nowrap absolute top-0 right-0 pt2 pr3">
        <div class="mr2">
        </div>

    </div>
</header>

<!-- Start Sidebar -->
<amp-sidebar id="header-sidebar"
             class="ampstart-sidebar px3  md-flex flex-column justify-content items-center justify-center"
             layout="nodisplay">
    <div class="flex justify-start items-center ampstart-sidebar-header">
        <div role="button" aria-label="close sidebar" on="tap:header-sidebar.toggle" tabindex="0"
             class="ampstart-navbar-trigger items-start">✕
        </div>
    </div>
    <nav class="ampstart-sidebar-nav ampstart-nav">
        <ul class="list-reset m0 p0 ampstart-label">
            <li>
                <a href="<?=SITE_HOST?>" class="text-decoration-none block 22">
                    <amp-img src="<?=SITE_HOST?>/img/e-commerce/logo-nav.png" width="279" height="175" layout="responsive"
                             class="ampstart-sidebar-nav-image inline-block mb4" alt="Company logo" noloading="">
                        <div placeholder="" class="commerce-loader"></div>
                    </amp-img>
                </a>
            </li>
            <li class="ampstart-nav-item "><a class="ampstart-nav-link" href="privacy">Privacy Policy</a>
            </li>
            <li class="ampstart-nav-item "><a class="ampstart-nav-link" href="dmca">DMCA</a></li>
            <li class="ampstart-nav-item "><a class="ampstart-nav-link" href="contact">Contact us</a></li>
        </ul>
    </nav>
</amp-sidebar>
<!-- End Sidebar -->
<!-- End Navbar -->

<amp-state id="cart">
    <script type="application/json">
        {
            "added": false
        }
    </script>
</amp-state>

<main id="content" role="main" class="main">
    <div class="commerce-cart-notification fixed col-12 right-0 mx0 md-mx2">
        <h1 class="display-none   ">Your Basket</h1>
        <div class="commerce-cart-item flex flex-wrap items-center m0 p2 ">
            <div class="col-3 sm-col-2 md-col-2 lg-col-2">
                <amp-img class="commerce-cart-item-image" src="../../img/e-commerce/product/product-8.jpg" width="1"
                         height="1" layout="responsive" alt="Caliper Brakes" noloading="">
                    <div placeholder="" class="commerce-loader"></div>
                </amp-img>
            </div>
            <div class="commerce-cart-item-desc px1 col-6 sm-col-7 md-col-7 lg-col-7">
                <div class="h6 mb1">Caliper Brakes</div>
                <div>Fits most wheel sizes and designed to last long.</div>
            </div>
            <div class="commerce-cart-item-price col-3 h6 flex flex-wrap justify-around items-start">
                <span>£349</span>
                <span>1</span>
                <div role="button" class="inline-block commerce-cart-icon" tabindex="0">✕</div>
            </div>
        </div>
        <div class="commerce-cart-item flex flex-wrap items-center m0 p2 ">
            <div class="col-3 sm-col-2 md-col-2 lg-col-2">
                <amp-img class="commerce-cart-item-image" src="../../img/e-commerce/product/product-1.jpg" width="1"
                         height="1" layout="responsive" alt="Sprocket Set" noloading="">
                    <div placeholder="" class="commerce-loader"></div>
                </amp-img>
            </div>
            <div class="commerce-cart-item-desc px1 col-6 sm-col-7 md-col-7 lg-col-7">
                <div class="h6 mb1">Sprocket Set</div>
                <div>Steel, designed for long lasting stability.</div>
            </div>
            <div class="commerce-cart-item-price col-3 h6 flex flex-wrap justify-around items-start">
                <span>£470</span>
                <span>1</span>
                <div role="button" class="inline-block commerce-cart-icon" tabindex="0">✕</div>
            </div>
        </div>
        <div class="flex p2 mxn1 md-py3">
            <a href="#" class="ampstart-btn ampstart-btn-secondary caps center col col-6 mx1">send</a>
            <a href="checkout.amp.html" class="ampstart-btn caps center col col-6 mx1">checkout</a>
        </div>
    </div>

    <section class="flex flex-wrap pb4 md-pb7">
        <div class="col-12 flex flex-wrap pb3">
            <div class="col-12 md-col-12 px2 md-pl7 commerce-product-desc">
                <section class="pt3 md-pt6 md-px4">
                    <h2 class="h5 md-h4">Privacy Policy</h2>
                    <p>We recognize that your privacy is important. This document outlines the types of personal information we receive and collect when you use <?php echo DOMAIN;?>, as well as some of the steps we take to safeguard information. We hope this will help you make an informed decision about sharing personal information with us. <?php echo DOMAIN;?> strives to maintain the highest standards of decency, fairness and integrity in all our operations. Likewise, we are dedicated to protecting our customers&acute;, consumers&acute; and online visitors privacy on our website.</p>
                    <h2>Personal Information</h2>
                    <p><?php echo DOMAIN;?> collects personally identifiable information from the visitors to our website only on a voluntary basis. Personal information collected on a voluntary basis may include name, postal address, email address, company name and telephone number.</p>
                    <p>This information is collected if you request information from us, participate in a contest or sweepstakes, and sign up to join our email list or request some other service or information from us. The information collected is internally reviewed, used to improve the content of our website, notify our visitors of updates, and respond to visitor inquiries.</p>
                    <p>Once information is reviewed, it is discarded or stored in our files. If we make material changes in the collection of personally identifiable information we will inform you by placing a notice on our site. Personal information received from any visitor will be used only for internal purposes and will not be sold or provided to third parties.</p>
                    <h2>Use of Cookies and Web Beacons</h2>
                    <p>We may use cookies to help you personalize your online experience. Cookies are identifiers that are transferred to your computer&acute;s hard drive through your Web browser to enable our systems to recognize your browser. The purpose of a cookie is to tell the Web server that you have returned to a specific page. For example, if you personalize the sites pages, or register with any of our site&acute;s services, a cookie enables <?php echo DOMAIN;?> to recall your specific information on subsequent visits.</p>
                    <p>You have the ability to accept or decline cookies by modifying your Web browser; however, if you choose to decline cookies, you may not be able to fully experience the interactive features of the site.</p>
                    <p>A web beacon is a transparent image file used to monitor your journey around a single website or collection of sites. They are also referred to as web bugs and are commonly used by sites that hire third-party services to monitor traffic. They may be used in association with cookies to understand how visitors interact with the pages and content on the pages of a web site.</p>
                    <p>We may serve third-party advertisements that use cookies and web beacons in the course of ads being served on our web site to ascertain how many times you&acute;ve seen an advertisement. No personally identifiable information you give us is provided to them for cookie or web beacon use, so they cannot personally identify you with that information on our web site.</p>
                    <p>Some third-party advertisements may be provided by Google, which uses cookies to serve ads on this site. Google uses the DART cookie, which enables it to serve ads to our users based on their visits to this site and other sites on the Web. You may opt out of the use of the DART cookie by visiting the Google ad and content network privacy policy.</p>
                    <p>Browsers can be set to accept or reject cookies or notify you when a cookie is being sent. Privacy software can be used to override web beacons. Taking either of these actions shouldn&acute;t cause a problem with our site, should you so choose.</p>
                    <h2>Children&acute;s Online Privacy Protection Act</h2>
                    <p>This website is directed to adults; it is not directed to children under the age of 13. We operate our site in compliance with the Children&acute;s Online Privacy Protection Act, and will not knowingly collect or use personal information from anyone under 13 years of age.</p>
                    <h2>Non-Personal Information</h2>
                    <p>In some cases, we may collect information about you that is not personally identifiable. We use this information, which does not identify individual users, to analyze trends, to administer the site, to track users&acute; movements around the site and to gather demographic information about our user base as a whole. The information collected is used solely for internal review and not shared with other organizations for commercial purposes.</p>
                    <h2>Release of Information</h2>
                    <p>If <?php echo DOMAIN;?> is sold, the information we have obtained from you through your voluntary participation in our site may transfer to the new owner as a part of the sale in order that the service being provided to you may continue. In that event, you will receive notice through our website of that change in control and practices, and we will make reasonable efforts to ensure that the purchaser honors any opt-out requests you might make of us.</p>
                    <h2>How You Can Correct or Remove Information</h2>
                    <p>We provide this privacy policy as a statement to you of our commitment to protect your personal information. If you have submitted personal information through our website and would like that information deleted from our records or would like to update or correct that information, please use our <a href="<?php echo $site_url;?>/contact-us">Contact Us</a> page.</p>
                    <h2>Updates and Effective Date</h2>
                    <p><?php echo DOMAIN;?> reserves the right to make changes in this policy. If there is a material change in our privacy practices, we will indicate on our site that our privacy practices have changed and provide a link to the new privacy policy. We encourage you to periodically review this policy so that you will know what information we collect and how we use it.</p>
                    <h2>Agreeing to Terms</h2>
                    <p>If you do not agree to <?php echo DOMAIN;?> Privacy Policy as posted here on this website, please do not use this site or any services offered by this site.</p>
                    <p>Your use of this site indicates acceptance of this privacy policy.</p>
                </section>
            </div>
        </div>
    </section>


</main>
<?php
include_once 'footer.php';
?>
</body>
</html>
