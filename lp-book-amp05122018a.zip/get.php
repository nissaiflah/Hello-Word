<?php
require_once('simple_html_dom.php');
include_once 'config.php';
function slugify($text)
{
    // replace non letter or digits by -
    $text = preg_replace('~[^\pL\d]+~u', '-', $text);

    // transliterate
    $text = iconv('utf-8', 'us-ascii//TRANSLIT', $text);

    // remove unwanted characters
    $text = preg_replace('~[^-\w]+~', '', $text);

    // trim
    $text = trim($text, '-');

    // remove duplicate -
    $text = preg_replace('~-+~', '-', $text);

    // lowercase
    $text = strtolower($text);

    if (empty($text)) {
        return 'n-a';
    }

    return $text;
}

function baca($url, $referer = 'http://www.google.com/firefox?client=firefox-a&rls=org.mozilla:fr:official', $ua = 'Mozilla/5.0 (Windows; U; Windows NT 6.1; en-US; rv:1.9.2.18) Gecko/20110614 Firefox/3.6.18')
{
    if (function_exists('curl_exec')) {
        $curl = curl_init();
        $header[0] = "Accept: text/xml,application/xml,application/xhtml+xml,";
        $header[0] .= "text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5";
        $header[] = "Cache-Control: max-age=0";
        $header[] = "Connection: keep-alive";
        $header[] = "Keep-Alive: 300";
        $header[] = "Accept-Charset: ISO-8859-1,utf-8;q=0.7,*;q=0.7";
        $header[] = "Accept-Language: en-us,en;q=0.5";
        $header[] = "Pragma: ";
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_USERAGENT, $ua);
        curl_setopt($curl, CURLOPT_HTTPHEADER, $header);
        curl_setopt($curl, CURLOPT_REFERER, $referer);
        curl_setopt($curl, CURLOPT_ENCODING, 'gzip,deflate');
        curl_setopt($curl, CURLOPT_AUTOREFERER, true);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_TIMEOUT, 10);
        $content = curl_exec($curl);
        curl_close($curl);
    } else {
        ini_set('user_agent', $ua);
        $content = file_get_contents($url);
    }
    if ($content == '') {
        ini_set('user_agent', $ua);
        $content = file_get_contents($url);
    }
    return $content;
}

function addSitemap($link)
{
    $arrExp = explode('videos', $link);
    $jml1 = count($arrExp);
    $arrExp2 = explode('story', $link);
    $jml2 = count($arrExp2);
    $linkArr = explode(',', file_get_contents('.site'));
    if (!in_array($link, $linkArr) && $jml1 < 2 && $jml2 < 2) {
        $linkNew = $link . ',' . implode(',', $linkArr);
        file_put_contents('.site', $linkNew);
    }
}

function addRecentSearch($kw)
{
    $kwArr = explode(',', file_get_contents('.search'));
    if (!in_array($kw, $kwArr)) {
        $kwNew = $kw . ',' . implode(',', $kwArr);
        file_put_contents('.search', $kwNew);
    }
}

function addDataNew($data)
{
    $allData = file_get_contents('.chache');
    $allDataArr = json_decode($allData);
//    print_r($allDataArr);exit;
    $newData = array();
    if (!in_array($data, $allDataArr)) {
        array_push($newData,$data);
        for($c=0;$c<299;$c++){
            array_push($newData,$allDataArr[$c]);
        }
        $newDataJson = json_encode($newData);
        file_put_contents('.chache', $newDataJson);
    }
}

function addSingle($data)
{
//    print_r($data['slug']);exit();
    $allData = file_get_contents('.single');
    $allDataArr = json_decode($allData, true);
//    print_r($allDataArr);exit();
    $newData = array();
    if (!in_array($data, $allDataArr)) {
        $newData[$data['slug']] = $data;
        $v=0;
        foreach($allDataArr as $val){
            if($v==50){break;}
            $newData[$val['slug']] = $val;
            $v++;
        }
//        print_r($newData);exit();
        $newDataJson = json_encode($newData);
        file_put_contents('.single', $newDataJson);
    }
}

//fungsi untuk follow redirect
function get_final_url($url, $timeout = 5)
{
    $url = str_replace("&amp;", "&", urldecode(trim($url)));
    $cookie = tempnam("/tmp", "CURLCOOKIE");

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows; U; Windows NT 5.1; rv:1.7.3) Gecko/20041001 Firefox/0.10.1");
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_COOKIEJAR, $cookie);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_ENCODING, "");
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_AUTOREFERER, true);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
    curl_setopt($ch, CURLOPT_MAXREDIRS, 10);
    $content = curl_exec($ch);
    $response = curl_getinfo($ch);
    curl_close($ch);

    if ($response['http_code'] == 301 || $response['http_code'] == 302) {
        ini_set("user_agent", "Mozilla/5.0 (Windows; U; Windows NT 5.1; rv:1.7.3) Gecko/20041001 Firefox/0.10.1");
        $headers = get_headers($response['url']);

        $location = "";
        foreach ($headers as $value) {
            if (substr(strtolower($value), 0, 9) == "location:")
                return get_final_url(trim(substr($value, 9, strlen($value))));
        }
    }

    if (preg_match("/window\.location\.replace\('(.*)'\)/i", $content, $value) ||
        preg_match("/window\.location\=\"(.*)\"/i", $content, $value)
    ) {
        return get_final_url($value[1]);
    } else {
        return $response['url'];
    }
}

function get_newrelease()
{
    $url = "http://www.goodreads.com/book";
//echo $url;exit();

    $load = baca($url);
    $html2 = str_get_html($load);
    $dataBook = array();
    $innerDiv = $html2->find("div[class=\"elementList\"]");
    $x = 0;
    $i = 6;
    foreach ($innerDiv as $divHtml) {
        $html = str_get_html($divHtml->innertext);
//        print_r($divHtml->innertext);exit();
        $link = $html->find("a", 0)->href;
        addSitemap($link);
        $idNol = str_replace('/book/show/', '', $link);
        $idArr = explode('-', $idNol);
        $id = $idArr[0];
        $img = str_replace('s/' . $id, 'l/' . $id, $html->find("img", 0)->src);
        $title = $html->find("a[class=\"bookTitle\"]", 0)->plaintext;
        $author = $html2->find("span[itemprop=name]", $x)->plaintext;
        $rating = $html2->find("span[class=\"greyText smallText\"]", $x)->plaintext;
        $ratingArr = explode('—', $rating);
        $rating = $ratingArr[0] . 'of' . $ratingArr[1];
        $dataBook[$x] = array();
        $dataBook[$x]['title'] = preg_replace('/\s+/', ' ', $title);
        $dataBook[$x]['id'] = $id;
        $dataBook[$x]['img'] = $img;
        $dataBook[$x]['link'] = $link;
        $dataBook[$x]['author'] = $author;
        $dataBook[$x]['rating'] = preg_replace('/\s+/', ' ', $rating);
        $x++;
        $i++;
    }
    return $dataBook;
}

function getDataHome($param='')
{
    $dataJson = str_replace('{},', '', file_get_contents('.chache'));
    $dataBook = json_decode($dataJson, true);
    $dataReturn = array();
    $dataReturn['items']=array();
    $single = array();
    $i=0;
//    print_r($dataBook);exit;
    foreach ($dataBook as $val){
        if($i==52){break;}$i++;

        $single['name'] = ucwords(str_replace('-',' ',slugify($val['title'])));
        $single['description'] = ucwords(str_replace('-',' ',slugify($val['title'])));
        $single['price'] = 'Free';
        $single['image'] = str_replace("l/".$val['id'],"m/".$val['id'],$val['img']);
        $single['category'] = $val['id'];
//        $single['slug'] = $val['link'];

        $link = str_replace("/book/show/","",$val['link']);
        $linkArr = explode('-',slugify($link));
        $idBook = $linkArr[0];
        unset($linkArr[0]);
        $slug = implode('-',$linkArr);

        $single['slug'] = "/$idBook/$slug";
        $single['teslink'] = $val['link'];
        array_push($dataReturn['items'],$single);
    }
    print_r(json_encode($dataReturn));exit;
//    return $dataBook;
}

function get_related()
{
    $dataJson = file_get_contents('.chache');
    $dataBook = json_decode($dataJson, true);
    return $dataBook;
}

function get_single_json($idBookSlug)
{
    $slug = $idBookSlug;
    $slug = str_replace('.pdf', '', $slug);
//    echo $slug;exit;
    $dataJson = file_get_contents('.single');

    $dataBookarr = json_decode($dataJson, true);
    if(!isset($dataBookarr[$slug])){
        $dataBook = get_single($slug);
    }else{
        $dataBook = $dataBookarr[$slug];
    }

    if(count($dataBook)==0){
        $titleSlug = ucwords(str_replace('-',' ',$slug));
        $arrTitle = explode(' ',$titleSlug);
        unset($arrTitle[0]);
        $titleSlug=implode(' ',$arrTitle);
        /*ubah atau modifikasi kalimat deskripsi ini sesuai kebutuhan kita*/
        $desc ="Read or Download $titleSlug Free pdf download sites is give to you by ".DOMAIN." with no fee and special for you.
             UNLIMITED BOOKS, ALL IN ONE PLACE. FREE TO TRY FOR 30 DAYS. SUBSCRIBE TO READ OR DOWNLOAD EBOOK FOR FREE. 
             START YOUR FREE MONTH NOW!
             ";
        $dataBook['title'] = $titleSlug;
        $dataBook['desc'] = $desc;
        $dataBook['img'] = SITE_HOST.'/img/pdf.png';
        $dataBook['isbn'] = rand(84398758,99898989);
        $dataBook['format'] = "PDF";
        $dataBook['language'] = "English";
        $dataBook['published'] = "Published ".date('M')." ".rand(1,30)."th ".rand(2002,2018)." by Book Publishing ";
        $dataBook['author'] = "";
        $authorImg = SITE_HOST."/img/us1.png";
        $dataBook['bookAuthorProfile__photo'] = $authorImg;

    }
    $dataReturn = array();
    $dataReturn['items']=array();
    array_push($dataReturn['items'],$dataBook);
    print_r(json_encode($dataReturn));exit;
}

function get_search($kw)
{
    if(@$page != 'tag.php'){
        $kw = urlencode($kw);
    }
    addRecentSearch($kw);

    $url = "https://www.goodreads.com/search?q=$kw";
    if (isset($_GET['page'])) {
        $url .= "&page=" . $_GET['page'];
    }

    $load = baca($url);
    $html2 = str_get_html($load);
    $recordCount = $html2->find('h3[class="searchSubNavContainer"]', 0)->plaintext;
    $recordArr = explode('of about ', $recordCount);
    $recordArr2 = explode(' results', $recordArr[1]);
    $totalRecord = $recordArr2[0];

    $dataBook = array();
    $innerTr = $html2->find("tr[itemtype=\"http://schema.org/Book\"]");
    $x = 0;
    $i = 6;
    $dataReturn = array();
    $dataReturn['items']=array();
    foreach ($innerTr as $trHtml) {
        $html = str_get_html($trHtml->innertext);
        $link = str_replace('?from_search=true', '', $html->find("a[class=\"bookTitle\"]", 0)->href);

        $id = $html->find('div[class="u-anchorTarget"]', 0)->id;
        $img = str_replace('s/' . $id, 'l/' . $id, $html->find("img[class=\"bookSmallImg\"]", 0)->src);
        $img = str_replace('s/' . $id, 'l/' . $id, $html->find("img[class=\"bookCover\"]", 0)->src);
        $imgArr = explode('/',$img);
        $id1 = str_replace('i','l',$imgArr[count($imgArr)-2]);
        $id2arr = explode('.',$imgArr[count($imgArr)-1]);
        $id2 = $id2arr[0];
        $img = "https://images.gr-assets.com/books/$id1/$id2.jpg";

        $title = $html->find("a[class=\"bookTitle\"]", 0)->plaintext;
        $author = $html->find("a[class=\"authorName\"]", 0)->plaintext;
        $rating = $html2->find("span[class=\"minirating\"]", $x)->plaintext;
        $ratingArr = explode(' — ', $rating);
        $rating = str_replace('—', 'of', $ratingArr[0]);
        $dataBook[$x] = array();
        $dataBook[$x]['title'] = preg_replace('/\s+/', ' ', $title);;
        $dataBook[$x]['id'] = $id;
        $dataBook[$x]['img'] = $img;
//        $dataBook[$x]['link'] = $link;
        $dataBook[$x]['author'] = $author;
        $dataBook[$x]['rating'] = preg_replace('/\s+/', ' ', $rating);;

        $link = str_replace("/book/show/","",$link);
        $linkArr = explode('-',slugify($link));
        $idBook = $linkArr[0];
        unset($linkArr[0]);
        $slug = implode('-',$linkArr);

        $dataBook[$x]['link'] = "/$idBook/$slug";
//        $single['teslink'] = $val['link'];


//        print_r($dataBook[$x]);exit();
        array_push($dataReturn['items'],$dataBook[$x]);
        addDataNew($dataBook[$x]);
        $x++;
        $i++;
    }
    echo json_encode($dataReturn);exit;
    /*$dataBook['total_record'] = (int)$totalRecord;
    return $dataBook;*/
}

function get_genre($kw)
{
    addRecentSearch($kw);
    $url = "https://www.goodreads.com/genres/new_releases/$kw";

    $load = baca($url);
    $html2 = str_get_html($load);
    $dataBook = array();
    $innerTr = $html2->find("div[class=\"leftAlignedImage bookBox\"]");
    $x = 0;
    $i = 6;
    foreach ($innerTr as $trHtml) {
        $html = str_get_html($trHtml->innertext);
        $idArr = explode('_', $html->find('div[class="coverWrapper"]', 0)->id);
        $id = $idArr[1];
        $img = $html->find("img", 0)->src;
        $link = $html->find("a", 0)->href;
        $title = $html->find("img", 0)->alt;
        /*$rating = $html2->find("span[class=\"minirating\"]",$x)->plaintext;
        $ratingArr = explode(' — ',$rating);
        $rating = str_replace('—','of',$ratingArr[0]);*/
        $dataBook[$x] = array();
        $dataBook[$x]['title'] = preg_replace('/\s+/', ' ', $title);;
        $dataBook[$x]['id'] = $id;
        $dataBook[$x]['img'] = $img;
        $dataBook[$x]['link'] = $link;
        $dataBook[$x]['rating'] = rand(4, 5);

        addSitemap($link);
        addDataNew($dataBook[$x]);
        $x++;
        $i++;
    }
    return $dataBook;
}

function get_single($slug)
{
    $slug = str_replace('.pdf', '', $slug);
    $slugify = slugify($slug);
    $url = "https://www.goodreads.com/book/show/$slug";
    $load1 = baca($url);
    $slugArr = explode('-',$slugify);
    $z = 0;
    $tag = array();
    foreach ($slugArr as $val){
        if($z==0){$z++;continue;}
        $tag[]=$val;
    }
    $tag = implode('-',$tag);
    $loadArr = explode('lazy_loadable_view',$load1);
    $load = $loadArr[0];
//    echo $load;exit;
    $html2 = str_get_html($load);
    $html3 = str_get_html($loadArr[1]);
    $dataBook = array();
    if(count($loadArr)>1){
        $dataBook['title'] = strip_tags($html2->find('h1[id="bookTitle"]', 0)->plaintext);
        $dataBook['slug'] = $slug;
        $dataBook['desc'] = str_replace('...more','',strip_tags($html2->find('div[id="description"]', 0)->plaintext)) ;
        $dataBook['author'] = $html2->find('span[itemprop="name"]', 0)->innertext;
        $dataBook['ratingvalue'] = $html2->find('span[itemprop="ratingValue"]', 0)->innertext;
        $dataBook['ratingcount'] = $html2->find('meta[itemprop="ratingCount"]', 0)->innertext;
        $dataBook['img'] = $html2->find('img[id="coverImage"]', 0)->src;
        $authorImg = $html3->find('div[class="bookAuthorProfile__photo"]', 0)->style;
        $authorImg = str_replace(['background-image: url(',');'],'',$authorImg);
        if($authorImg==''){
            $authorImg = SITE_HOST."/img/us1.png";
        }

        $dataBook['bookAuthorProfile__photo'] = $authorImg;

        $imgArr = explode('/', $dataBook['img']);
        $dataBook['img_med'] = str_replace('l/' . $imgArr[count($imgArr) - 1], 'm/' . $imgArr[count($imgArr) - 1], $dataBook['img']);
        $dataBook['isbn'] = $html2->find('meta[property=\'books:isbn\']', 0)->content;
        $detail = $html2->find('div[id="details"]', 0)->innertext;

        $htmlDetail = str_get_html($detail);
        $dataBook['format'] = $htmlDetail->find('div[class="row"]', 0)->plaintext;
        $dataBook['published'] = $htmlDetail->find('div[class="row"]', 1)->plaintext;
//    $dataBook['published']=$htmlDetail->find('nobr[class="greyText"]',0)->plaintext;
        $dataBook['language'] = $htmlDetail->find('div[itemprop="inLanguage"]', 0)->plaintext;
        $dataSingle = array();
        $dataSingle[$slug] = $dataBook;
        addSingle($dataBook);
    }
//    print_r($dataBook);exit();
    return $dataBook;
}

if(isset($_GET['action'])){
    $_GET['action']($_GET['param']);
}