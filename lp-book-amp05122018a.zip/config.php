<?php
session_start();
error_reporting(0);
include_once "db_connect.php";

$country='US';
$ip = $_SERVER['REMOTE_ADDR'];
$xml = simplexml_load_file("http://ip-api.com/xml/" . $ip);
$country = $xml->countryCode;

$protocol = 'http';
$ArrUrl = explode('/', ($_SERVER['HTTP_HOST'] == 'localhost') ? $_SERVER['REQUEST_URI'] : "/" . $_SERVER['REQUEST_URI']);
$page = (isset($ArrUrl[2]) && !empty($ArrUrl[2])) ? $ArrUrl[2] . ".php" : "home.php";
$id = (isset($ArrUrl[3])) ? $ArrUrl[3] : ""; // print_r($idYt);exit();
$subActionPage = (isset($ArrUrl[4])) ? $ArrUrl[4] : "";
date_default_timezone_set('Asia/Jakarta');

if (!defined('HOST_URI')) define("HOST_URI", ($_SERVER['HTTP_HOST'] == 'localhost') ? "/" . $ArrUrl[1] : "");
if (!defined('SITE_HOST')) define("SITE_HOST", "$protocol://" . $_SERVER['HTTP_HOST'] . HOST_URI);
if (!defined('DOMAIN')) define("DOMAIN", str_replace("www.", "", str_replace("$protocol://", "", SITE_HOST)));
if (!defined('CONTACT')) define("CONTACT", "support@." . DOMAIN . ".com");

if (!defined('SITE_TITLE')) define("SITE_TITLE", "Ebook Gratuit");

/*setting link cpa berdasarkan negara*/
if(in_array($country,explode(',',file_get_contents(SITE_HOST.'/negara/.tier1')))){
    /*cpa link untuk negara-negara tier 1 cukup ganti url facebook.com dengan link cpa anda*/
    $cpa_link="http://books.media-filez.com/downloadt.php?";
}else if(in_array($country,explode(',',file_get_contents(SITE_HOST.'/negara/.tier2')))){
    /*cpa link untuk negara-negara tier 2 cukup ganti url google.com dengan link cpa anda*/
    $cpa_link="http://books.media-filez.com/readt.php?";
}else if(in_array($country,explode(',',file_get_contents(SITE_HOST.'/negara/.tier3')))){
    /*cpa link untuk negara-negara tier 3 cukup ganti url twitter.com dengan link cpa anda*/
    $cpa_link="http://books.media-filez.com/readt.php?";
}else{
    /*cpa link untuk negara-negara yang tidak masuk di semua tier cukup ganti url blogger.com dengan link cpa anda*/
    $cpa_link="http://books.media-filez.com/downloadt.php?";
}

if (!defined('LINK_CPA')) define('LINK_CPA', $cpa_link);
?>