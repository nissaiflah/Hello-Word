<?php
include_once 'config.php';
include_once 'get.php';

if($page=='home.php' || $page=='search.php' || $page=='contact.php' || $page=='dmca.php' || $page=='contact.php'
    || $page=='sitemap.php' || $page=='map.php'
){
    include_once $page;
}else{
    include_once "book.php";
}
