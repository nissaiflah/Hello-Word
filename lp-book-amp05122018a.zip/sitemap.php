<?php
include_once 'config.php';
header('Content-type: application/xml; charset="ISO-8859-1"', true);
$dataKw = file_get_contents('.site');
$data = explode(',',$dataKw);

$dataKw2 = file_get_contents('.keywords');
$data2 = explode(',',$dataKw2);

$dataAll = array_merge($data,$data2);

$jmlData = count($dataAll);
$jmlPage = round($jmlData/1000);
if($jmlPage==0){$jmlPage=1;}

$sitemap = '<?xml version="1.0" encoding="UTF-8"?>';
$sitemap .= '<sitemapindex xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';
$thn = date('Y');
$bln = date('m');

for ($i=0;$i<$jmlPage;$i++) {
    $sitemap .='<sitemap>
                   <loc>'.SITE_HOST.'/map/'.$i.'</loc>
                   <lastmod>'.$thn.'-'.$bln.'-01</lastmod>
                </sitemap>';

}
echo $sitemap;
print_r('</sitemapindex>');
