<!---
Copyright 2017 The AMP Start Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS-IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-->
<?php
include_once '../config.php';
//$dataSingle = get_single_json($slug);
//print_r($dataSingle);exit;
?>
<!doctype html>
<html ⚡="" lang="en">

<head>
    <meta charset="utf-8">
    <title>DMCA Notice</title>
    <link rel="canonical" href="https://www.ampstart.com/templates/themes/e-commerce/product-details.amp">
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">

    <script async="" src="https://cdn.ampproject.org/v0.js"></script>
    <script async custom-element="amp-list" src="https://cdn.ampproject.org/v0/amp-list-0.1.js"></script>


    <style amp-boilerplate="">
        body {
            -webkit-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
            -moz-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
            -ms-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
            animation: -amp-start 8s steps(1, end) 0s 1 normal both
        }

        @-webkit-keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }

        @-moz-keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }

        @-ms-keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }

        @-o-keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }

        @keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }</style>
    <noscript>
        <style amp-boilerplate="">body {
                -webkit-animation: none;
                -moz-animation: none;
                -ms-animation: none;
                animation: none
            }</style>
    </noscript>


    <script custom-element="amp-sidebar" src="https://cdn.ampproject.org/v0/amp-sidebar-0.1.js" async=""></script>
    <script custom-element="amp-bind" src="https://cdn.ampproject.org/v0/amp-bind-0.1.js" async=""></script>
    <script custom-element="amp-carousel" src="https://cdn.ampproject.org/v0/amp-carousel-0.1.js" async=""></script>
    <script custom-element="amp-selector" src="https://cdn.ampproject.org/v0/amp-selector-0.1.js" async=""></script>

    <script custom-template="amp-mustache" src="https://cdn.ampproject.org/v0/amp-mustache-0.1.js" async=""></script>

    <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,700" rel="stylesheet">

    <link href="<?=SITE_HOST?>/css/custom.css" rel="stylesheet">
</head>

<body [class]="cart.added ? 'commerce-cart-added' : ''">

<!-- Start Navbar -->
<header class="ampstart-headerbar fixed flex justify-start items-center top-0 left-0 right-0 pl2 pr4 pt2 md-pt0">
    <div role="button" aria-label="open sidebar" on="tap:header-sidebar.toggle" tabindex="0"
         class="ampstart-navbar-trigger  pr2 absolute top-0 pr0 mr2 mt2">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" class="block">
            <path fill="none" d="M0 0h24v24H0z"></path>
            <path fill="currentColor" d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"></path>
        </svg>
    </div>
    <a href="<?=SITE_HOST?>"
       class="text-decoration-none inline-block mx-auto ampstart-headerbar-home-link mb1 md-mb0 ">
        <amp-img src="<?=SITE_HOST?>/img/e-commerce/logo.png" width="200" height="75" layout="fixed" class="my0 mx-auto "
                 alt="">

        </amp-img>
    </a>
    <!--
      TODO: currently "fixeditems" is an array, therefore it's not possible to
      add additional classes to it. An alternative solution would be to make it
      an oject, with a "classes" and "items" sub-properties:
     "fixeditems": {
       "classes": "col-3",
       "items": [{
         "link": {
           "url": "mailto:contact@lune.com",
           "text": "—contact@lune.com",
           "classes": "xs-small sm-hide h6 bold"
         }
       }]
     }
     -->
    <div class="ampstart-headerbar-fixed center m0 p0 flex justify-center nowrap absolute top-0 right-0 pt2 pr3">
        <div class="mr2">
        </div>

    </div>
</header>

<!-- Start Sidebar -->
<amp-sidebar id="header-sidebar"
             class="ampstart-sidebar px3  md-flex flex-column justify-content items-center justify-center"
             layout="nodisplay">
    <div class="flex justify-start items-center ampstart-sidebar-header">
        <div role="button" aria-label="close sidebar" on="tap:header-sidebar.toggle" tabindex="0"
             class="ampstart-navbar-trigger items-start">✕
        </div>
    </div>
    <nav class="ampstart-sidebar-nav ampstart-nav">
        <ul class="list-reset m0 p0 ampstart-label">
            <li>
                <a href="<?=SITE_HOST?>" class="text-decoration-none block 22">
                    <amp-img src="<?=SITE_HOST?>/img/e-commerce/logo-nav.png" width="279" height="175" layout="responsive"
                             class="ampstart-sidebar-nav-image inline-block mb4" alt="Company logo" noloading="">
                        <div placeholder="" class="commerce-loader"></div>
                    </amp-img>
                </a>
            </li>
            <li class="ampstart-nav-item "><a class="ampstart-nav-link" href="privacy">Privacy Policy</a>
            </li>
            <li class="ampstart-nav-item "><a class="ampstart-nav-link" href="dmca">DMCA</a></li>
            <li class="ampstart-nav-item "><a class="ampstart-nav-link" href="contact">Contact us</a></li>
        </ul>
    </nav>
</amp-sidebar>
<!-- End Sidebar -->
<!-- End Navbar -->

<amp-state id="cart">
    <script type="application/json">
        {
            "added": false
        }
    </script>
</amp-state>

<main id="content" role="main" class="main">
    <div class="commerce-cart-notification fixed col-12 right-0 mx0 md-mx2">
        <h1 class="display-none   ">Your Basket</h1>
        <div class="commerce-cart-item flex flex-wrap items-center m0 p2 ">
            <div class="col-3 sm-col-2 md-col-2 lg-col-2">
                <amp-img class="commerce-cart-item-image" src="../../img/e-commerce/product/product-8.jpg" width="1"
                         height="1" layout="responsive" alt="Caliper Brakes" noloading="">
                    <div placeholder="" class="commerce-loader"></div>
                </amp-img>
            </div>
            <div class="commerce-cart-item-desc px1 col-6 sm-col-7 md-col-7 lg-col-7">
                <div class="h6 mb1">Caliper Brakes</div>
                <div>Fits most wheel sizes and designed to last long.</div>
            </div>
            <div class="commerce-cart-item-price col-3 h6 flex flex-wrap justify-around items-start">
                <span>£349</span>
                <span>1</span>
                <div role="button" class="inline-block commerce-cart-icon" tabindex="0">✕</div>
            </div>
        </div>
        <div class="commerce-cart-item flex flex-wrap items-center m0 p2 ">
            <div class="col-3 sm-col-2 md-col-2 lg-col-2">
                <amp-img class="commerce-cart-item-image" src="../../img/e-commerce/product/product-1.jpg" width="1"
                         height="1" layout="responsive" alt="Sprocket Set" noloading="">
                    <div placeholder="" class="commerce-loader"></div>
                </amp-img>
            </div>
            <div class="commerce-cart-item-desc px1 col-6 sm-col-7 md-col-7 lg-col-7">
                <div class="h6 mb1">Sprocket Set</div>
                <div>Steel, designed for long lasting stability.</div>
            </div>
            <div class="commerce-cart-item-price col-3 h6 flex flex-wrap justify-around items-start">
                <span>£470</span>
                <span>1</span>
                <div role="button" class="inline-block commerce-cart-icon" tabindex="0">✕</div>
            </div>
        </div>
        <div class="flex p2 mxn1 md-py3">
            <a href="#" class="ampstart-btn ampstart-btn-secondary caps center col col-6 mx1">send</a>
            <a href="checkout.amp.html" class="ampstart-btn caps center col col-6 mx1">checkout</a>
        </div>
    </div>

    <section class="flex flex-wrap pb4 md-pb7">
        <div class="col-12 flex flex-wrap pb3">
            <div class="col-12 md-col-12 px2 md-pl7 commerce-product-desc">
                <section class="pt3 md-pt6 md-px4">
                    <h2 class="h5 md-h4">DMCA</h2>
                    <p class="mt2 mb3">
                    <p><?=DOMAIN?> respects the intellectual property of others. </p>
                    <p><?=DOMAIN?> takes matters of Intellectual Property very seriously and is committed to meeting the needs of content owners while helping them manage publication of their content online. It should be noted that <?=DOMAIN?> is a simple search engine of videos available at a wide variety of third party websites. </p>
                    <p>Any videos shown on third party websites are the responsibility of those sites and not <?=DOMAIN?>. We have no knowledge of whether content shown on third party websites is or is not authorized by the content owner as that is a matter between the host site and the content owner. <?=DOMAIN?> does not host any content on its servers or network. </p>
                    <p>If you believe that your copyrighted work has been copied in a way that constitutes copyright infringement and is accessible on this site, you may notify our copyright agent, as set forth in the Digital Millennium Copyright Act of 1998 (DMCA). For your complaint to be valid under the DMCA, you must provide the following information when providing notice of the claimed copyright infringement:</p>
                    <p>A physical or electronic signature of a person authorized to act on behalf of the copyright owner Identification of the copyrighted work claimed to have been infringed.</p>
                    <p>Identification of the material that is claimed to be infringing or to be the subject of the infringing activity and that is to be removed. Information reasonably sufficient to permit the service provider to contact the complaining party, such as an address, telephone number, and, if available, an electronic mail address.</p>
                    <p>A statement that the complaining party "in good faith believes that use of the material in the manner complained of is not authorized by the copyright owner, its agent, or law" A statement that the "information in the notification is accurate", and "under penalty of perjury, the complaining party is authorized to act on behalf of the owner of an exclusive right that is allegedly infringed" The above information must be submitted as a written, faxed or emailed notification to the following Designated Agent:</p>
                    <p>&nbsp;</p>
                    <p>Attn: DMCA Office</p>

                    <p><?=DOMAIN?></p>
                    <p>&nbsp;</p>
                    <p>WE CAUTION YOU THAT UNDER FEDERAL LAW, IF YOU KNOWINGLY MISREPRESENT THAT ONLINE MATERIAL IS INFRINGING, YOU MAY BE SUBJECT TO HEAVY CIVIL PENALTIES. THESE INCLUDE MONETARY DAMAGES, COURT COSTS, AND ATTORNEYS' FEES INCURRED BY US, BY ANY COPYRIGHT OWNER, OR BY ANY COPYRIGHT OWNER'S LICENSEE THAT IS INJURED AS A RESULT OF OUR RELYING UPON YOUR MISREPRESENTATION. YOU MAY ALSO BE SUBJECT TO CRIMINAL PROSECUTION FOR PERJURY.</p>
                    <p>This information should not be construed as legal advice, for further details on the information required for valid DMCA notifications, see 17 U.S.C. 512(c)(3).</p>

                    </p>
                </section>
            </div>
        </div>
    </section>


</main>
<?php
include_once 'footer.php';
?>
</body>
</html>
