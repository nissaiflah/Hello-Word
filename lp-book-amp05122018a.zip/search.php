<!doctype html>

<!---
Copyright 2017 The AMP Start Authors. All Rights Reserved.

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

      http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS-IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
-->

<html ⚡="" lang="en">

<head>
    <meta charset="utf-8">

    <title>Search Result : <?=$_GET['q']?></title>
    <meta content="<?=$_GET['q']?>,free book, textbook, study book, student, calculus, career, e-books, ebooks, economics" name="keywords"/>
    <meta content="Download <?=$_GET['q']?> textbooks and business books in PDF format. The books are financed by a few in-book ads." name="description"/>

    <link rel="canonical" href="https://www.ampstart.com/templates/e-commerce/product-listing.amp">
    <meta name="viewport" content="width=device-width,minimum-scale=1,initial-scale=1">

    <script async="" src="https://cdn.ampproject.org/v0.js"></script>


    <style amp-boilerplate="">
        body {
            -webkit-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
            -moz-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
            -ms-animation: -amp-start 8s steps(1, end) 0s 1 normal both;
            animation: -amp-start 8s steps(1, end) 0s 1 normal both
        }

        @-webkit-keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }

        @-moz-keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }

        @-ms-keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }

        @-o-keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }

        @keyframes -amp-start {
            from {
                visibility: hidden
            }
            to {
                visibility: visible
            }
        }</style>
    <noscript>
        <style amp-boilerplate="">body {
                -webkit-animation: none;
                -moz-animation: none;
                -ms-animation: none;
                animation: none
            }</style>
    </noscript>

    <script async custom-element="amp-form" src="https://cdn.ampproject.org/v0/amp-form-0.1.js"></script>
    <script custom-element="amp-sidebar" src="https://cdn.ampproject.org/v0/amp-sidebar-0.1.js" async=""></script>
    <script custom-element="amp-list" src="https://cdn.ampproject.org/v0/amp-list-0.1.js" async=""></script>
    <script custom-element="amp-bind" src="https://cdn.ampproject.org/v0/amp-bind-0.1.js" async=""></script>

    <script custom-template="amp-mustache" src="https://cdn.ampproject.org/v0/amp-mustache-0.1.js" async=""></script>

    <link href="https://fonts.googleapis.com/css?family=Open+Sans+Condensed:300,700" rel="stylesheet">

    <link href="<?=SITE_HOST?>/css/custom.css" rel="stylesheet">
</head>
<body>

<!-- Start Navbar -->
<header class="ampstart-headerbar fixed flex justify-start items-center top-0 left-0 right-0 pl2 pr4 pt2 md-pt0">
    <div role="button" aria-label="open sidebar" on="tap:header-sidebar.toggle" tabindex="0"
         class="ampstart-navbar-trigger  pr2 absolute top-0 pr0 mr2 mt2">
        <svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewbox="0 0 24 24" class="block">
            <path fill="none" d="M0 0h24v24H0z"></path>
            <path fill="currentColor" d="M3 18h18v-2H3v2zm0-5h18v-2H3v2zm0-7v2h18V6H3z"></path>
        </svg>
    </div>
    <a href="<?=SITE_HOST?>"
       class="text-decoration-none inline-block mx-auto ampstart-headerbar-home-link mb1 md-mb0 ">
        <amp-img src="<?=SITE_HOST?>/img/e-commerce/logo.png" width="200" height="75" layout="fixed" class="my0 mx-auto "
                 alt=""></amp-img>
    </a>
    <div class="ampstart-headerbar-fixed center m0 p0 flex justify-center nowrap absolute top-0 right-0 pt2 pr3">
        <div class="mr2">
        </div>
    </div>
</header>

<!-- Start Sidebar -->
<amp-sidebar id="header-sidebar"
             class="ampstart-sidebar px3  md-flex flex-column justify-content items-center justify-center"
             layout="nodisplay">
    <div class="flex justify-start items-center ampstart-sidebar-header">
        <div role="button" aria-label="close sidebar" on="tap:header-sidebar.toggle" tabindex="0"
             class="ampstart-navbar-trigger items-start">✕
        </div>
    </div>
    <nav class="ampstart-sidebar-nav ampstart-nav">
        <ul class="list-reset m0 p0 ampstart-label">
            <li>
                <a href="<?=SITE_HOST?>" class="text-decoration-none block 22">
                    <amp-img src="<?=SITE_HOST?>/img/e-commerce/logo-nav.png" width="279" height="175" layout="responsive"
                             class="ampstart-sidebar-nav-image inline-block mb4" alt="Company logo" noloading="">
                        <div placeholder="" class="commerce-loader"></div>
                    </amp-img>
                </a>
            </li>
            <li class="ampstart-nav-item "><a class="ampstart-nav-link" href="privacy">Privacy Policy</a>
            </li>
            <li class="ampstart-nav-item "><a class="ampstart-nav-link" href="dmca">DMCA</a></li>
            <li class="ampstart-nav-item "><a class="ampstart-nav-link" href="contact">Contact us</a></li>
        </ul>
    </nav>

</amp-sidebar>
<!-- End Sidebar -->
<!-- End Navbar -->
<main id="content" role="main" class="main commerce-listing">
    <amp-state id="products">
        <script type="application/json">
            {
                "category": "all",
                "filter": "high-low"
            }
        </script>
    </amp-state>
    <amp-img class="commerce-listing-banner xs-hide sm-hide" src="<?=SITE_HOST?>/img/e-commerce/wide-listings-hero.jpg" width="2560"
             height="300" layout="responsive" alt="Product listing" noloading="">
        <div placeholder="" class="commerce-loader"></div>
    </amp-img>
    <section class="commerce-listing-content mx-auto flex flex-wrap pb4">
        <div class="col-3 xs-hide sm-hide flex flex-column">
            <div class="commerce-side-panel pt4 pr4 self-center">
                <div class="commerce-side-panel pt4 pr4 self-center">
                    <?php
                    include_once 'adsense.php';
                    ?>
                </div>
            </div>
        </div>

        <div class="col-12 md-col-7 pt2 pb3 md-px4 md-pt1 md-pb7">
            <form method="GET"
                  class="p2"
                  action="<?=SITE_HOST?>/search/"
                  target="_top">
                <div class="ampstart-input inline-block relative mb3 customSearch">
                    <input class="ampstart-input" type="search" placeholder="Search book..." name="q">
                </div>
            </form>

            <div class="md-commerce-header relative md-flex flex-wrap items-center md-mx0 md-mb2">
                <h1 class="h3 mb2 md-mt2 md-mb2 md-ml0 flex-auto px2">Search Result : <?=$_GET['q']?></h1>
            </div>

            <amp-list class="mx1 md-mxn1" [src]="'api/' + products.filter + '-' + products.category + '-products.json'"
                      src="//<?=DOMAIN?>/get.php?action=get_search&param=<?=$_GET['q']?>" height="500" width="300" layout="responsive">
                <template type="amp-mustache">
                    <a href="<?=SITE_HOST?>{{link}}" target="_self"
                       class="commerce-listing-product text-decoration-none inline-block col-6 md-col-4 lg-col-3 px1 mb2 md-mb4 relative">
                        <div class="flex flex-column justify-between">
                            <div>
                                <amp-img class="commerce-listing-product-image mb2" src="{{img}}" width="340"
                                         height="340" layout="responsive" alt="{{ title }}" noloading="">
                                    <div placeholder="" class="commerce-loader"></div>
                                </amp-img>
                                <h2 class="commerce-listing-product-name h6">{{ title }}</h2>
                            </div>
                        </div>
                    </a>
                </template>
            </amp-list>
        </div>
    </section>
</main>
<?php
include_once 'footer.php';
?>
</body>
</html>
