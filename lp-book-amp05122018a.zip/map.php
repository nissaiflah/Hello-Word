<?php
include_once 'get.php';

header('Content-type: application/xml; charset="ISO-8859-1"', true);
$dataKw = file_get_contents('.site');
$data = explode(',',$dataKw);

$dataKw2 = file_get_contents('.keywords');
$data2 = explode(',',$dataKw2);

$dataAll = array_merge($data,$data2);
//print_r($dataAll);exit();

$mulai = (int)$id*1000;
$akhir = $mulai + 1000;

$sitemap = '<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">';

if($id==0){
    $sitemap .= '<url>
                        <loc>' . SITE_HOST . '</loc>
                        <priority>1.0</priority>
                     </url>';
}

for($i=$mulai;$i<$akhir;$i++){
    if(!isset($dataAll[$i])){break;}
    if($dataAll[$i]==''){continue;}

    $link = str_replace("/book/show/","",$dataAll[$i]);
    $linkArr = explode('-',slugify($link));

    if(substr($dataAll[$i],0,11)=='/book/show/'){
        $idBook = $linkArr[0];
        unset($linkArr[0]);
        $slug = implode('-',$linkArr);
        $singleSlug = "/$idBook/$slug";

        $sitemap .= '<url>
                        <loc>' . SITE_HOST . $singleSlug.'</loc>
                        <priority>0.9</priority>
                        <changefreq>daily</changefreq>
                     </url>';
    }else{
        $slug = implode('-',$linkArr);
        $idBook = rand(0,10000)."l";
        $singleSlug = "/$idBook/$slug";
        $sitemap .= '<url>
                        <loc>' . SITE_HOST .$singleSlug.'</loc>
                        <priority>0.7</priority>
                        <changefreq>daily</changefreq>
                     </url>';
    }


}

echo $sitemap;
print_r('</urlset>');
